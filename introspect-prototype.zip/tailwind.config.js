/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        background: '#09090E',
        surface: {
          DEFAULT: '#11111A',
          subtle: '#171724',
          card: '#13131D',
          hover: '#1B1B2A',
          border: '#242436',
          borderLight: '#32324C',
        },
        accent: {
          purple: '#9353d3',
          purpleLight: '#c084fc',
          purpleDark: '#6b21a8',
          blue: '#3b82f6',
          cyan: '#06b6d4',
          cyanLight: '#38bdf8',
          emerald: '#10b981',
          amber: '#f59e0b',
          rose: '#f43f5e',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 25px -5px rgba(147, 83, 211, 0.25)',
        cyanGlow: '0 0 25px -5px rgba(6, 182, 212, 0.25)',
        card: '0 4px 20px -2px rgba(0, 0, 0, 0.45)',
      }
    },
  },
  plugins: [],
}
