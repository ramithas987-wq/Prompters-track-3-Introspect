# INTROSPECT — Personal Intelligence System

> **Ideathon Prototype (Track Submission)**  
> *Transforming fragmented smartphone & wearable signals into actionable lifestyle intelligence.*

---

## 📌 Executive Concept

Most health and digital wellbeing applications operate in **isolated data silos**:
* **Smartwatches & Fitness Trackers** record sleep duration, heart rate, and workouts, but cannot explain *why* sleep deteriorated or recovery stalled.
* **Screen Time & Digital Wellbeing Tools** count screen hours, app usage, and notifications, but have zero awareness of your physical state or circadian rhythm.

**INTROSPECT** bridges this chasm. It combines the data streams your phone already passively collects to detect hidden causal relationships between digital behaviors and physical health.

```
┌─────────────────────────────────┐
│           1. COLLECT            │
│  Sleep • Steps • Workouts • HR  │
│  Screen Time • Pickups • Apps   │
└────────────────┬────────────────┘
                 │
                 ▼
┌─────────────────────────────────┐
│          2. UNDERSTAND          │
│ Multi-variate correlation engine│
│ Finds cross-domain causalities  │
└────────────────┬────────────────┘
                 │
                 ▼
┌─────────────────────────────────┐
│             3. ACT              │
│ Contextual micro-interventions  │
│ Personalized habit adjustments  │
└─────────────────────────────────┘
```

---

## 🚀 Key Features in this Prototype

### 1. Unified Dashboard
* **Health & Activity**:
  * 💤 **Sleep Duration**: 6h 45m (Deep sleep: 1h 20m, REM: 1h 45m)
  * 👟 **Steps**: 8,432 (+18% vs last week)
  * 🏃 **Exercise**: 4 workouts this week (Weekly target achieved)
  * ❤️ **Resting Heart Rate**: 64 BPM (Normal baseline)
* **Digital Behaviour**:
  * 📱 **Screen Time**: 6h 32m (Peak between 8 PM - 11 PM)
  * 📸 **Most Used App**: Instagram (2h 14m)
  * 🖐️ **Phone Pickups**: 72 pickups / day
  * 🔔 **Notifications**: 146 notifications
  * 🌙 **Late-Night Usage**: 1h 15m (after 11:00 PM)

### 2. Behavioural Insights (Cross-Domain Engine)
1. **Screen Time + Sleep Correlation**: Higher late-night screen usage is strongly associated with a 45–70 min drop in sleep duration and delayed melatonin onset.
2. **Exercise + Sleep Synergy**: Workouts before 6:30 PM correlate with a +34% surge in deep restorative sleep and 75% fewer nocturnal awakenings.
3. **Digital Behaviour Concentration**: Over 54% of screen intake is clustered between 8 PM and 11 PM.
4. **Activity Momentum**: 18% weekly step increase linked directly to afternoon walking blocks.

### 3. Cross-Domain Intelligence (Interactive Graphs)
* **Comparison 1**: Screen Time vs. Sleep Duration (inverse correlation).
* **Comparison 2**: Exercise Minutes vs. Deep Sleep Stages (recovery synergy).
* **Comparison 3**: Late-Night Usage vs. Next-Day Step Count (circadian fatigue effect).

### 4. "Your Day at a Glance" Daily Synthesis
An executive daily summary providing a high-level takeaway of your lifestyle harmony index score and immediate actionable micro-steps.

---

## 🛠️ Tech Stack

* **Framework**: React 18 + Vite
* **Styling**: Tailwind CSS (Custom Charcoal & Obsidian Dark Theme with Purple/Cyan Accents)
* **Visualizations**: Recharts
* **Icons**: Lucide React
* **Data State**: Clean, deterministic DEMO DATA layer for rapid demonstration and zero network latency.

---

## 🏃 How to Run Locally

### Prerequisites
* Node.js (v18 or higher recommended)
* npm or pnpm

### Setup Instructions
```bash
# 1. Clone or navigate to the directory
cd introspect-prototype

# 2. Install dependencies
npm install

# 3. Start local development server
npm run dev

# 4. Or build and preview production bundle
npm run build
npm run preview
```

Open `http://localhost:3000` (or the URL shown in your terminal) in your browser.

---

## 🎯 Ideathon Video & Pitch Structure (3–5 min Guide)

1. **Problem (0:00 - 1:00)**: Show how users switch between Apple Health and Screen Time without actionable answers.
2. **Solution (1:00 - 2:00)**: Walk through the INTROSPECT Dashboard and explain the *Collect · Understand · Act* framework.
3. **Demo (2:00 - 3:30)**: Highlight the **Cross-Domain Intelligence** charts showing the exact statistical link between late-night Instagram use and next-day lethargy.
4. **Impact & Future (3:30 - 4:00)**: On-device private AI models synthesizing health habits without uploading personal telemetry to external servers.

---

*Clearly labeled as DEMO DATA for Ideathon Presentation.*
