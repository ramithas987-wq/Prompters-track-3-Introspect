import React, { useState } from 'react';
import Header from './components/Header';
import ConceptHero from './components/ConceptHero';
import DailySummary from './components/DailySummary';
import Dashboard from './components/Dashboard';
import BehaviouralInsights from './components/BehaviouralInsights';
import CrossDomainIntelligence from './components/CrossDomainIntelligence';
import PitchOverviewModal from './components/PitchOverviewModal';
import { 
  Sparkles, 
  Layers, 
  Smartphone, 
  Heart, 
  ShieldCheck, 
  Info,
  Presentation,
  CheckCircle2,
  ArrowUp
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [pitchModalOpen, setPitchModalOpen] = useState(false);

  const scrollToSection = (id) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#09090e] text-slate-100 flex flex-col font-sans selection:bg-purple-500/30 selection:text-purple-200">
      
      {/* Top sticky Navigation Header */}
      <Header 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        onOpenPitchModal={() => setPitchModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Tab 1: Dashboard (Default View with all core sections) */}
        {activeTab === 'dashboard' && (
          <>
            {/* Concept Hero: Collect · Understand · Act */}
            <ConceptHero 
              onExploreInsights={() => setActiveTab('insights')} 
            />

            {/* Daily Summary: "Your Day at a Glance" */}
            <DailySummary 
              onJumpToInsights={() => setActiveTab('insights')} 
            />

            {/* Health & Activity + Digital Behaviour Metric Cards */}
            <Dashboard 
              onSelectInsight={() => setActiveTab('insights')} 
            />

            {/* Behavioural Insights Preview */}
            <BehaviouralInsights 
              onJumpToGraphs={() => setActiveTab('cross-domain')} 
            />

            {/* Cross-Domain Intelligence Comparison Graphs */}
            <CrossDomainIntelligence />
          </>
        )}

        {/* Tab 2: Behavioural Insights Focused View */}
        {activeTab === 'insights' && (
          <div className="space-y-6">
            <DailySummary 
              onJumpToInsights={() => {}} 
            />
            <BehaviouralInsights 
              onJumpToGraphs={() => setActiveTab('cross-domain')} 
            />
          </div>
        )}

        {/* Tab 3: Cross-Domain Intelligence Focused View */}
        {activeTab === 'cross-domain' && (
          <div className="space-y-6">
            <CrossDomainIntelligence />
          </div>
        )}

        {/* Tab 4: How It Works / Collect · Understand · Act */}
        {activeTab === 'concept' && (
          <div className="space-y-6">
            <ConceptHero 
              onExploreInsights={() => setActiveTab('insights')} 
            />
            <CrossDomainIntelligence />
            <BehaviouralInsights 
              onJumpToGraphs={() => setActiveTab('cross-domain')} 
            />
          </div>
        )}

      </main>

      {/* Pitch Guide / Ideathon Presentation Modal */}
      <PitchOverviewModal 
        isOpen={pitchModalOpen} 
        onClose={() => setPitchModalOpen(false)} 
      />

      {/* Footer */}
      <footer className="border-t border-surface-border bg-[#0b0b13] py-8 mt-16 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <span className="font-extrabold font-mono text-slate-300">INTROSPECT</span>
            <span>•</span>
            <span>Personal Intelligence System</span>
            <span>•</span>
            <span className="text-purple-400 font-mono">DEMO DATA</span>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => setPitchModalOpen(true)}
              className="text-purple-300 hover:text-white transition-colors"
            >
              Ideathon Pitch Guide
            </button>
            <span>•</span>
            <span className="text-slate-400">
              Collect ➔ Understand ➔ Act
            </span>
          </div>
        </div>
      </footer>

    </div>
  );
}
