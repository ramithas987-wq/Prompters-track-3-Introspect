import React from 'react';
import { 
  Activity, 
  Sparkles, 
  ShieldCheck, 
  Presentation, 
  HelpCircle,
  Menu,
  X
} from 'lucide-react';

export default function Header({ activeTab, setActiveTab, onOpenPitchModal }) {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard & Metrics' },
    { id: 'insights', label: 'Behavioural Insights', badge: '4 New' },
    { id: 'cross-domain', label: 'Cross-Domain Intelligence' },
    { id: 'concept', label: 'How It Works (Collect · Understand · Act)' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#09090e]/90 backdrop-blur-md border-b border-surface-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-600 via-indigo-600 to-cyan-500 p-[1px] flex items-center justify-center shadow-glow">
              <div className="w-full h-full bg-[#0d0d15] rounded-[11px] flex items-center justify-center">
                <Activity className="w-5 h-5 text-purple-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold tracking-wider text-lg text-white font-mono">
                  INTROSPECT
                </span>
                <span className="px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider bg-purple-500/10 text-purple-300 border border-purple-500/20 rounded-full">
                  Prototype
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">
                Personal Intelligence System
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all duration-200 flex items-center space-x-2 ${
                    isActive
                      ? 'bg-purple-600/15 text-purple-300 border border-purple-500/30 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-surface-subtle'
                  }`}
                >
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="text-[10px] px-1.5 py-0.2 bg-purple-500/20 text-purple-300 rounded font-mono">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action / Badges */}
          <div className="hidden sm:flex items-center space-x-3">
            {/* Demo Data Tag */}
            <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-700/60 text-[11px] text-slate-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-mono text-slate-400">DEMO DATA</span>
            </div>

            {/* Ideathon Pitch Guide Button */}
            <button
              onClick={onOpenPitchModal}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-glow transition-all"
            >
              <Presentation className="w-3.5 h-3.5" />
              <span>Pitch Concept</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex lg:hidden items-center space-x-2">
            <button
              onClick={onOpenPitchModal}
              className="p-1.5 rounded-lg bg-purple-600/20 text-purple-300 border border-purple-500/30 text-xs"
              title="Pitch Guide"
            >
              <Presentation className="w-4 h-4" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-surface-subtle text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-surface-border bg-[#0d0d15] px-4 pt-2 pb-4 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2 text-sm font-medium rounded-lg flex items-center justify-between ${
                activeTab === item.id
                  ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30'
                  : 'text-slate-300 hover:bg-surface-subtle'
              }`}
            >
              <span>{item.label}</span>
              {item.badge && (
                <span className="text-[10px] px-1.5 py-0.5 bg-purple-500/20 text-purple-300 rounded font-mono">
                  {item.badge}
                </span>
              )}
            </button>
          ))}
          <div className="pt-2 flex items-center justify-between border-t border-surface-border/50 text-xs text-slate-400">
            <span>Status: Ideathon Prototype</span>
            <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-mono">DEMO DATA</span>
          </div>
        </div>
      )}
    </header>
  );
}
