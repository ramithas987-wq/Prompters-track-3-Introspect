import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  ComposedChart, 
  LineChart, 
  BarChart, 
  Bar, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  CartesianGrid, 
  Area 
} from 'recharts';
import { 
  Network, 
  Layers, 
  HelpCircle, 
  Smartphone, 
  Moon, 
  Flame, 
  Footprints, 
  ArrowRight,
  TrendingDown,
  TrendingUp,
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { 
  SCREEN_VS_SLEEP_DATA, 
  EXERCISE_VS_SLEEP_DATA, 
  LATE_PHONE_VS_STEPS_DATA 
} from '../data/mockData';

// Custom dark theme tooltip for Recharts
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#12121e] border border-surface-border p-3 rounded-xl shadow-card text-xs">
        <p className="font-semibold text-slate-200 mb-1.5 font-mono">{label}</p>
        {payload.map((entry, index) => (
          <div key={`item-${index}`} className="flex items-center justify-between space-x-3 py-0.5">
            <span className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="text-slate-400">{entry.name}:</span>
            </span>
            <span className="font-mono font-bold text-white">
              {entry.value} {entry.unit || ''}
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export default function CrossDomainIntelligence() {
  const [activeGraph, setActiveGraph] = useState('all');

  return (
    <section className="mb-12" id="cross-domain-section">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-1">
            <Network className="w-4 h-4" />
            <span>Multi-Sensor Synthesis</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Cross-Domain Intelligence
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            Ordinary trackers stay in isolated silos: Apple Health only tracks sleep, Screen Time only counts minutes. 
            Introspect bridges the gap by computing real-time correlations across domains.
          </p>
        </div>

        {/* Graph selector buttons */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-surface-card rounded-xl border border-surface-border">
          {[
            { id: 'all', label: 'All 3 Correlations' },
            { id: 'screen-sleep', label: '1. Screen vs Sleep' },
            { id: 'exercise-sleep', label: '2. Exercise vs Sleep' },
            { id: 'late-steps', label: '3. Late Phone vs Next-Day Steps' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveGraph(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeGraph === tab.id
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-surface-subtle'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-8">
        
        {/* GRAPH 1: Screen Time vs Sleep Duration */}
        {(activeGraph === 'all' || activeGraph === 'screen-sleep') && (
          <div className="rounded-2xl bg-surface-card border border-surface-border p-5 sm:p-6 shadow-card">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-6 pb-4 border-b border-surface-border/60">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-400" />
                  <h3 className="text-lg font-bold text-white">
                    Comparison 1: Daily Screen Time vs. Sleep Duration
                  </h3>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  7-Day Trend: Inverse relationship between total screen exposure and nighttime recovery
                </p>
              </div>
              <div className="flex items-center space-x-2 text-xs font-mono bg-purple-500/10 border border-purple-500/20 text-purple-300 px-3 py-1 rounded-lg">
                <TrendingDown className="w-3.5 h-3.5 text-purple-400" />
                <span>Correlation Factor: -0.74 (Strong Negative)</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              {/* Chart container */}
              <div className="lg:col-span-8 h-72 sm:h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={SCREEN_VS_SLEEP_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#252538" vertical={false} />
                    <XAxis dataKey="day" stroke="#64748b" tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="left" stroke="#a855f7" domain={[0, 10]} tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="right" orientation="right" stroke="#38bdf8" domain={[0, 10]} tick={{ fontSize: 11 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend 
                      verticalAlign="top" 
                      height={36}
                      formatter={(value) => <span className="text-xs text-slate-300">{value}</span>}
                    />
                    <Bar 
                      yAxisId="left" 
                      dataKey="screenTime" 
                      name="Screen Time (hrs)" 
                      fill="#8b5cf6" 
                      radius={[4, 4, 0, 0]} 
                      barSize={24}
                    />
                    <Line 
                      yAxisId="right" 
                      type="monotone" 
                      dataKey="sleepDuration" 
                      name="Sleep Duration (hrs)" 
                      stroke="#38bdf8" 
                      strokeWidth={3} 
                      dot={{ r: 4, fill: '#38bdf8' }}
                      activeDot={{ r: 6 }}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>

              {/* Side explanation */}
              <div className="lg:col-span-4 bg-[#0e0e18] p-4 sm:p-5 rounded-xl border border-surface-border space-y-3">
                <div className="flex items-center space-x-2 text-xs font-semibold text-purple-300 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>The Introspect Insight</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Notice how on <strong className="text-white">Wednesday</strong> and <strong className="text-white">Friday</strong>, 
                  when screen time spiked past 7 hours, sleep collapsed to under 6.2 hours.
                </p>
                <div className="p-3 bg-surface-card rounded-lg border border-purple-500/20 text-xs text-slate-400 space-y-1">
                  <div className="text-white font-semibold flex items-center space-x-1">
                    <span>Why Ordinary Apps Fail:</span>
                  </div>
                  <div>
                    Apple Health or Oura will tell you: <em>"You slept poorly."</em> They cannot tell you that 
                    Instagram scrolling past 11 PM was the causal trigger.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* GRAPH 2: Exercise vs Sleep Quality / Duration */}
        {(activeGraph === 'all' || activeGraph === 'exercise-sleep') && (
          <div className="rounded-2xl bg-surface-card border border-surface-border p-5 sm:p-6 shadow-card">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-6 pb-4 border-b border-surface-border/60">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  <h3 className="text-lg font-bold text-white">
                    Comparison 2: Physical Exercise vs. Deep Sleep Stages
                  </h3>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Cross-referencing workout duration against restorative deep sleep cycles
                </p>
              </div>
              <div className="flex items-center space-x-2 text-xs font-mono bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 px-3 py-1 rounded-lg">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                <span>Synergy Factor: +34% Deep Sleep Recovery</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              {/* Chart container */}
              <div className="lg:col-span-8 h-72 sm:h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={EXERCISE_VS_SLEEP_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#252538" vertical={false} />
                    <XAxis dataKey="day" stroke="#64748b" tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="left" stroke="#10b981" domain={[0, 70]} tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="right" orientation="right" stroke="#c084fc" domain={[0, 130]} tick={{ fontSize: 11 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend 
                      verticalAlign="top" 
                      height={36}
                      formatter={(value) => <span className="text-xs text-slate-300">{value}</span>}
                    />
                    <Bar 
                      yAxisId="left" 
                      dataKey="exerciseMins" 
                      name="Exercise (mins)" 
                      fill="#10b981" 
                      radius={[4, 4, 0, 0]} 
                      barSize={20}
                    />
                    <Bar 
                      yAxisId="right" 
                      dataKey="deepSleepMins" 
                      name="Deep Sleep (mins)" 
                      fill="#a855f7" 
                      radius={[4, 4, 0, 0]} 
                      barSize={20}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Side explanation */}
              <div className="lg:col-span-4 bg-[#0e0e18] p-4 sm:p-5 rounded-xl border border-surface-border space-y-3">
                <div className="flex items-center space-x-2 text-xs font-semibold text-emerald-300 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span>The Introspect Insight</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Workout days (<strong className="text-white">Mon, Wed, Fri, Sat</strong>) yield an average of 
                  <strong className="text-emerald-300"> 98 mins</strong> of restorative deep sleep, compared to only 
                  <strong className="text-slate-400"> 65 mins</strong> on sedentary rest days.
                </p>
                <div className="p-3 bg-surface-card rounded-lg border border-emerald-500/20 text-xs text-slate-400 space-y-1">
                  <div className="text-white font-semibold flex items-center space-x-1">
                    <span>Cross-Domain Value:</span>
                  </div>
                  <div>
                    Fitness trackers record calories burned, and sleep bands track stages. Introspect discovers 
                    the direct physiological payoff that motivates continued adherence.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* GRAPH 3: Late-Night Phone Usage vs Next-Day Steps */}
        {(activeGraph === 'all' || activeGraph === 'late-steps') && (
          <div className="rounded-2xl bg-surface-card border border-surface-border p-5 sm:p-6 shadow-card">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-6 pb-4 border-b border-surface-border/60">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                  <h3 className="text-lg font-bold text-white">
                    Comparison 3: Late-Night Phone Usage vs. Next-Day Activity
                  </h3>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Screen exposure past 11:00 PM directly compromises physical energy and movement the following day
                </p>
              </div>
              <div className="flex items-center space-x-2 text-xs font-mono bg-rose-500/10 border border-rose-500/20 text-rose-300 px-3 py-1 rounded-lg">
                <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                <span>Next-Day Step Drop: ~1,400 Steps per hour of late screen</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              {/* Chart container */}
              <div className="lg:col-span-8 h-72 sm:h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={LATE_PHONE_VS_STEPS_DATA} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#252538" vertical={false} />
                    <XAxis dataKey="day" stroke="#64748b" tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="left" stroke="#f43f5e" domain={[0, 120]} tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="right" orientation="right" stroke="#06b6d4" domain={[0, 11000]} tick={{ fontSize: 11 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend 
                      verticalAlign="top" 
                      height={36}
                      formatter={(value) => <span className="text-xs text-slate-300">{value}</span>}
                    />
                    <Bar 
                      yAxisId="left" 
                      dataKey="lateNightUsageMins" 
                      name="Late-Night Usage (mins)" 
                      fill="#f43f5e" 
                      radius={[4, 4, 0, 0]} 
                      barSize={20}
                    />
                    <Line 
                      yAxisId="right" 
                      type="monotone" 
                      dataKey="nextDaySteps" 
                      name="Next-Day Steps" 
                      stroke="#06b6d4" 
                      strokeWidth={3} 
                      dot={{ r: 4, fill: '#06b6d4' }}
                      activeDot={{ r: 6 }}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>

              {/* Side explanation */}
              <div className="lg:col-span-4 bg-[#0e0e18] p-4 sm:p-5 rounded-xl border border-surface-border space-y-3">
                <div className="flex items-center space-x-2 text-xs font-semibold text-rose-300 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-rose-400" />
                  <span>The Introspect Insight</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  When late-night screen time spiked to 108 minutes on Friday, next-day activity collapsed to 
                  <strong className="text-white"> 5,800 steps</strong> due to delayed circadian wakefulness and lethargy.
                </p>
                <div className="p-3 bg-surface-card rounded-lg border border-rose-500/20 text-xs text-slate-400 space-y-1">
                  <div className="text-white font-semibold flex items-center space-x-1">
                    <span>Actionable Conclusion:</span>
                  </div>
                  <div>
                    Cutting late-night screen time by just 45 minutes recovers an estimated 1,500 daily steps 
                    the next day without demanding more workout willpower.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>

    </section>
  );
}
