import React, { useState } from 'react';
import { 
  Sparkles, 
  Lightbulb, 
  CheckCircle2, 
  Layers, 
  ArrowRight, 
  Flame, 
  Moon, 
  Smartphone, 
  TrendingUp, 
  Filter,
  Check,
  Zap,
  Clock
} from 'lucide-react';
import { BEHAVIOURAL_INSIGHTS } from '../data/mockData';

export default function BehaviouralInsights({ onJumpToGraphs }) {
  const [activeFilter, setActiveFilter] = useState('all');
  const [appliedTips, setAppliedTips] = useState({});

  const toggleApplyTip = (id) => {
    setAppliedTips((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const filteredInsights = BEHAVIOURAL_INSIGHTS.filter((insight) => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'cross') return insight.badgeColor === 'purple' || insight.badgeColor === 'emerald';
    if (activeFilter === 'sleep') return insight.title.includes('Sleep');
    if (activeFilter === 'digital') return insight.title.includes('Digital') || insight.title.includes('Screen');
    return true;
  });

  return (
    <section className="mb-12" id="behavioural-insights-section">
      
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center space-x-2 text-purple-400 text-xs font-semibold uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Core Intelligence Engine</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Behavioural Insights
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            Introspect connects isolated data points across physical health and digital habits 
            to uncover hidden lifestyle causalities that traditional trackers miss.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-surface-card rounded-xl border border-surface-border self-start">
          {[
            { id: 'all', label: 'All Insights (4)' },
            { id: 'cross', label: 'Cross-Domain Fusions' },
            { id: 'sleep', label: 'Sleep & Recovery' },
            { id: 'digital', label: 'Digital Habits' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeFilter === tab.id
                  ? 'bg-purple-600/30 text-purple-200 border border-purple-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-surface-subtle'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Insights Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {filteredInsights.map((insight) => {
          const isApplied = !!appliedTips[insight.id];

          return (
            <div
              key={insight.id}
              className="rounded-2xl bg-surface-card border border-surface-border hover:border-purple-500/40 transition-all duration-300 p-6 flex flex-col justify-between relative group hover:shadow-glow"
            >
              {/* Card Header & Data Stream Fusion */}
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center space-x-2">
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md border ${
                      insight.badgeColor === 'purple' 
                        ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                        : insight.badgeColor === 'emerald'
                        ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                        : insight.badgeColor === 'cyan'
                        ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30'
                        : 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                    }`}>
                      {insight.badge}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {insight.impactLevel}
                    </span>
                  </div>

                  <span className="text-xs font-mono font-semibold text-purple-300 bg-[#0d0d16] px-2 py-0.5 rounded border border-surface-border">
                    {insight.stat}
                  </span>
                </div>

                {/* Connection mapping tag */}
                <div className="mb-3 px-3 py-1.5 rounded-lg bg-[#0e0e18] border border-surface-border/70 flex items-center space-x-2 text-xs">
                  <Layers className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                  <span className="font-mono text-slate-300 text-[11px] truncate">
                    {insight.connection}
                  </span>
                </div>

                {/* Main Headline */}
                <h3 className="text-lg font-bold text-white mb-2 leading-snug group-hover:text-purple-200 transition-colors">
                  {insight.summary}
                </h3>

                {/* Explanation */}
                <div className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4 bg-surface-subtle/50 p-3.5 rounded-xl border border-surface-border/50">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1 flex items-center space-x-1.5">
                    <span>Why This Happens (Analysis)</span>
                  </div>
                  {insight.explanation}
                </div>

                {/* Recommendation */}
                <div className="rounded-xl bg-purple-950/20 border border-purple-500/30 p-3.5 mb-4">
                  <div className="flex items-center space-x-1.5 text-purple-300 text-xs font-bold uppercase tracking-wider mb-1">
                    <Lightbulb className="w-3.5 h-3.5 text-purple-400" />
                    <span>Actionable Recommendation</span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed">
                    {insight.recommendation}
                  </p>
                </div>
              </div>

              {/* Card Footer: Sources & Intervention toggle */}
              <div className="pt-4 border-t border-surface-border/60 flex flex-wrap items-center justify-between gap-3 text-xs">
                {/* Data Sources */}
                <div className="flex items-center space-x-1.5">
                  <span className="text-[11px] text-slate-500 font-mono">Sensors:</span>
                  <div className="flex flex-wrap gap-1">
                    {insight.dataSources.map((source, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded bg-surface-subtle text-slate-300 text-[10px] font-medium border border-surface-border/60"
                      >
                        {source}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Simulated Action Button */}
                <button
                  onClick={() => toggleApplyTip(insight.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 ${
                    isApplied
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-surface-subtle hover:bg-surface-hover text-slate-300 hover:text-white border border-surface-border'
                  }`}
                >
                  {isApplied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Intervention Scheduled</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5 text-purple-400" />
                      <span>Adopt Recommendation</span>
                    </>
                  )}
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* Cross-Domain Link prompt */}
      <div className="mt-5 p-4 rounded-xl bg-gradient-to-r from-purple-950/20 via-slate-900 to-cyan-950/20 border border-purple-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 text-slate-300">
          <Layers className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>
            Want to see the raw visual evidence? Inspect the comparison graphs plotting these relationships.
          </span>
        </div>
        <button
          onClick={onJumpToGraphs}
          className="px-3.5 py-1.5 rounded-lg bg-surface-subtle hover:bg-surface-hover text-purple-300 border border-purple-500/30 font-medium self-start sm:self-auto flex items-center space-x-1.5 transition-all"
        >
          <span>Examine Correlation Graphs</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

    </section>
  );
}
