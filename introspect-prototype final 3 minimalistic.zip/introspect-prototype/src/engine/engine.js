/**
 * INTROSPECT — live insight engine (runs in the browser).
 *
 * Takes daily rows + which sources are switched on + how many days of history
 * to use, and returns: link tests with r, p, "X of Y days" and a confidence
 * label; personal baselines; and a weekly summary. Nothing is hard-coded.
 */
import { mean, sd, median, pearson, permutationP, slope, mulberry32 } from './stats';
import { METRICS, simulateDay, addDays, dayLabel, TODAY } from './dataset';

export const MIN_DAYS_FOR_LINKS = 14;

// The 8 relationship tests the engine runs.
export const LINK_TESTS = [
  { id: 'late_sleep', x: 'lateNightMins', y: 'sleepHrs', title: 'Late-night phone use ↔ Sleep', xPhrase: 'late-night phone use', yPhrase: 'sleep', highX: 'high late-screen nights', requires: ['screen', 'health'], domain: 'cross' },
  { id: 'screen_sleep', x: 'screenHrs', y: 'sleepHrs', title: 'Total screen time ↔ Sleep', xPhrase: 'screen time', yPhrase: 'sleep', highX: 'high screen-time days', requires: ['screen', 'health'], domain: 'cross' },
  { id: 'exercise_deep', x: 'exerciseMins', y: 'deepSleepMins', title: 'Exercise ↔ Deep sleep', xPhrase: 'exercise', yPhrase: 'deep sleep', highX: 'workout days', requires: ['health'], domain: 'health', splitAtZero: true },
  { id: 'late_nextsteps', x: 'lateNightMins', y: 'steps', lag: 1, title: 'Late-night phone use → Next-day steps', xPhrase: 'late-night phone use', yPhrase: 'next-day steps', highX: 'high late-screen nights', requires: ['screen', 'health'], domain: 'cross' },
  { id: 'pickups_sleep', x: 'pickups', y: 'sleepHrs', title: 'Phone pickups ↔ Sleep', xPhrase: 'phone pickups', yPhrase: 'sleep', highX: 'high-pickup days', requires: ['screen', 'health'], domain: 'cross' },
  { id: 'calendar_late', x: 'calendarHrs', y: 'lateNightMins', title: 'Busy schedule ↔ Late-night phone use', xPhrase: 'scheduled hours', yPhrase: 'late-night phone use', highX: 'busy days', requires: ['calendar', 'screen'], domain: 'cross' },
  { id: 'calendar_exercise', x: 'calendarHrs', y: 'exerciseMins', title: 'Busy schedule ↔ Exercise', xPhrase: 'scheduled hours', yPhrase: 'exercise', highX: 'busy days', requires: ['calendar', 'health'], domain: 'cross' },
  { id: 'notif_steps', x: 'notifications', y: 'steps', title: 'Notifications ↔ Steps', xPhrase: 'notifications', yPhrase: 'steps', highX: 'high-notification days', requires: ['screen', 'health'], domain: 'cross' },
];

export const CONFIDENCE = {
  strong: { label: 'Strong link', tone: 'emerald' },
  moderate: { label: 'Moderate link', tone: 'amber' },
  none: { label: 'No clear link', tone: 'slate' },
  insufficient: { label: 'Not enough data yet', tone: 'sky' },
  locked: { label: 'Source switched off', tone: 'rose' },
};

const strengthWord = (r) => {
  const a = Math.abs(r);
  if (a >= 0.7) return 'strong';
  if (a >= 0.5) return 'clear';
  if (a >= 0.3) return 'moderate';
  return 'weak';
};

const fmtDelta = (key, v) => {
  const m = METRICS[key];
  const sign = v > 0 ? '+' : v < 0 ? '−' : '';
  const a = Math.abs(v);
  if (m.unit === 'h') return `${sign}${Math.round(a * 60)} min`;
  if (m.unit === 'min') return `${sign}${Math.round(a)} min`;
  return `${sign}${Math.round(a).toLocaleString('en-IN')}${m.unit ? ` ${m.unit}` : ''}`;
};

function runLinkTest(test, rows) {
  const xs = [];
  const ys = [];
  for (let i = test.lag || 0; i < rows.length; i += 1) {
    xs.push(rows[i - (test.lag || 0)][test.x]);
    ys.push(rows[i][test.y]);
  }
  const n = xs.length;
  const r = pearson(xs, ys);
  const p = n >= 5 ? permutationP(xs, ys, r, 2000, 11 + test.id.length) : 1;

  // "X of Y days": on high-x days, how often was y on the side the link predicts?
  const xCut = test.splitAtZero ? 0 : median(xs);
  const yMed = median(ys);
  const highIdx = xs.map((x, i) => (x > xCut ? i : -1)).filter((i) => i >= 0);
  const lowIdx = xs.map((x, i) => (x <= xCut ? i : -1)).filter((i) => i >= 0);
  const predictsLower = r < 0;
  const hits = highIdx.filter((i) => (predictsLower ? ys[i] < yMed : ys[i] > yMed)).length;
  const effect = mean(highIdx.map((i) => ys[i])) - mean(lowIdx.map((i) => ys[i]));
  const perUnit = slope(xs, ys);

  let confidence;
  if (n < MIN_DAYS_FOR_LINKS) confidence = 'insufficient';
  else if (p < 0.01 && Math.abs(r) >= 0.5) confidence = 'strong';
  else if (p < 0.05 && Math.abs(r) >= 0.3) confidence = 'moderate';
  else confidence = 'none';

  let sentence;
  if (confidence === 'insufficient') {
    sentence = `Only ${n} days of data. Introspect waits for at least ${MIN_DAYS_FOR_LINKS} days before calling this a link.`;
  } else if (confidence === 'none') {
    sentence = `No clear link between ${test.xPhrase} and ${test.yPhrase} in your last ${n} days. Introspect won't make a suggestion from this.`;
  } else {
    const verb = /s$/.test(test.yPhrase) ? 'were' : 'was';
    sentence = `On ${hits} of ${highIdx.length} ${test.highX}, your ${test.yPhrase} ${verb} ${predictsLower ? 'below' : 'above'} your usual (${fmtDelta(test.y, effect)} on average).`;
  }

  return {
    ...test, n, r, p, hits, highCount: highIdx.length, effect, effectText: fmtDelta(test.y, effect),
    perUnit, confidence, strength: strengthWord(r), sentence,
    points: xs.map((x, i) => ({ x, y: ys[i] })),
  };
}

export function computeBaselines(rows) {
  const history = rows.slice(0, -1);
  const today = rows[rows.length - 1];
  const out = {};
  Object.keys(METRICS).forEach((key) => {
    const vals = history.map((d) => d[key]);
    const m = mean(vals);
    const s = sd(vals);
    out[key] = { mean: m, sd: s, today: today[key], z: s ? (today[key] - m) / s : 0, n: vals.length };
  });
  return out;
}

export function weeklySummary(rows) {
  if (rows.length < 14) return null;
  const week = rows.slice(-7);
  const before = rows.slice(0, -7);
  const out = {};
  Object.keys(METRICS).forEach((key) => {
    const w = mean(week.map((d) => d[key]));
    const b = mean(before.map((d) => d[key]));
    const s = sd(before.map((d) => d[key]));
    out[key] = { week: w, before: b, sd: s, z: s ? (w - b) / s : 0 };
  });
  return { metrics: out, weekStart: week[0].date, weekEnd: week[6].date, baselineDays: before.length };
}

export function runEngine(dataset, sources, windowDays) {
  const t0 = typeof performance !== 'undefined' ? performance.now() : 0;
  const rows = dataset.slice(-windowDays);
  const tests = LINK_TESTS.map((test) => {
    const locked = test.requires.some((s) => !sources[s]);
    if (locked) return { ...test, locked: true, confidence: 'locked', n: 0, r: 0, p: 1, points: [] };
    return { ...runLinkTest(test, rows), locked: false };
  });
  const baselines = computeBaselines(rows);
  const weekly = weeklySummary(rows);
  const ms = typeof performance !== 'undefined' ? performance.now() - t0 : 0;
  return { rows, tests, testsById: Object.fromEntries(tests.map((t) => [t.id, t])), baselines, weekly, ms, windowDays };
}

// ---------- Nudge Lab ----------

export const NUDGES = [
  {
    id: 'phone_down',
    title: 'Phone down at 10:30 PM',
    why: 'Late-night phone use is your strongest link with shorter sleep.',
    basedOn: 'late_sleep',
    target: 'sleepHrs',
    mods: { lateFactor: 0.35 },
    requires: ['screen', 'health'],
    check: 'Compare your sleep over the next 7 nights with your normal range.',
  },
  {
    id: 'early_workout',
    title: 'Work out before 6:30 PM, 5 days',
    why: 'Workout days line up with more deep sleep for you.',
    basedOn: 'exercise_deep',
    target: 'deepSleepMins',
    mods: { workoutChance: 0.72 },
    requires: ['health'],
    check: 'Compare deep sleep over the next 7 nights with your normal range.',
  },
  {
    id: 'notif_off',
    title: 'Silence notifications after 10 PM',
    why: 'Pickups and late-night use rise together with shorter sleep.',
    basedOn: 'pickups_sleep',
    target: 'sleepHrs',
    mods: { lateFactor: 0.7, pickupFactor: 0.8 },
    requires: ['screen', 'health'],
    check: 'Compare your sleep over the next 7 nights with your normal range.',
  },
];

/**
 * Simulates the 7 days after starting a nudge using the same day model,
 * then checks the result against the personal baseline.
 * Adherence is not perfect: ~1 in 5 days the user forgets.
 */
export function simulateNudgeWeek(nudge, dataset, windowDays, runId = 1) {
  const rand = mulberry32(9000 + runId * 31 + nudge.id.length);
  const rows = dataset.slice(-windowDays);
  const base = rows.map((d) => d[nudge.target]);
  const bMean = mean(base);
  const bSd = sd(base);
  const days = [];
  let prevLate = rows[rows.length - 1].lateNightMins;
  for (let i = 1; i <= 7; i += 1) {
    const date = addDays(TODAY, i);
    const followed = rand() > 0.2;
    const d = simulateDay(rand, { date, prevLate }, followed ? nudge.mods : {});
    days.push({ date, label: dayLabel(date), followed, value: d[nudge.target], lateNightMins: d.lateNightMins });
    prevLate = d.lateNightMins;
  }
  const wMean = mean(days.map((d) => d.value));
  const zShift = bSd ? (wMean - bMean) / bSd : 0;
  const better = METRICS[nudge.target].better === 'up' ? 1 : -1;
  const daysBetter = days.filter((d) => (d.value - bMean) * better > 0).length;
  const followedDays = days.filter((d) => d.followed).length;
  let verdict;
  if (zShift * better >= 0.5 && daysBetter >= 5) verdict = { key: 'promising', label: 'Promising', text: 'Clearly better than your normal on most days. Keep it for one more week to confirm.' };
  else if (zShift * better >= 0.2) verdict = { key: 'early', label: 'Too early to tell', text: 'A small change. One week is not enough to be sure, so keep checking.' };
  else verdict = { key: 'none', label: 'No clear change', text: 'No clear difference from your normal. Introspect will suggest something else.' };
  return { days, bMean, bSd, wMean, zShift, daysBetter, followedDays, verdict, deltaText: fmtDelta(nudge.target, wMean - bMean) };
}
