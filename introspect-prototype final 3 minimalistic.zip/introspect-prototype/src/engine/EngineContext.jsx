import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { DATASET, SOURCES } from './dataset';
import { runEngine, LINK_TESTS } from './engine';

const EngineContext = createContext(null);

export function EngineProvider({ children }) {
  const [sources, setSources] = useState({ health: true, screen: true, calendar: true });
  const [windowDays, setWindowDays] = useState(28);
  const [toasts, setToasts] = useState([]);
  const [pulse, setPulse] = useState(0); // bumps on every recompute, drives a small animation
  const toastId = useRef(0);

  const result = useMemo(() => runEngine(DATASET, sources, windowDays), [sources, windowDays]);

  useEffect(() => {
    setPulse((p) => p + 1);
  }, [result]);

  const notify = useCallback((text, tone = 'purple') => {
    toastId.current += 1;
    const id = toastId.current;
    setToasts((t) => [...t.slice(-2), { id, text, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  const toggleSource = useCallback((key) => {
    const wasOn = sources[key];
    const affected = LINK_TESTS.filter((t) => t.requires.includes(key)).length;
    setSources((prev) => ({ ...prev, [key]: !prev[key] }));
    if (wasOn) notify(`${SOURCES[key].label} disconnected: ${affected} link tests locked`, 'rose');
    else notify(`${SOURCES[key].label} connected: ${affected} link tests unlocked`, 'emerald');
  }, [notify, sources]);

  const changeWindow = useCallback((days) => {
    setWindowDays(days);
    notify(`Engine re-ran on the last ${days} days of data`, 'cyan');
  }, [notify]);

  const value = useMemo(() => ({
    sources, toggleSource, windowDays, setWindowDays: changeWindow, result, dataset: DATASET, notify, pulse,
  }), [sources, toggleSource, windowDays, changeWindow, result, notify, pulse]);

  return (
    <EngineContext.Provider value={value}>
      {children}
      <div className="fixed bottom-5 right-5 z-[70] flex flex-col items-end gap-2 pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`toast-in pointer-events-auto px-4 py-2.5 rounded-xl text-xs font-medium border shadow-card backdrop-blur-md ${
              t.tone === 'rose'
                ? 'bg-rose-950/80 border-rose-500/40 text-rose-200'
                : t.tone === 'emerald'
                ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-200'
                : t.tone === 'cyan'
                ? 'bg-cyan-950/80 border-cyan-500/40 text-cyan-200'
                : 'bg-purple-950/80 border-purple-500/40 text-purple-200'
            }`}
          >
            {t.text}
          </div>
        ))}
      </div>
    </EngineContext.Provider>
  );
}

export function useEngine() {
  const ctx = useContext(EngineContext);
  if (!ctx) throw new Error('useEngine must be used inside <EngineProvider>');
  return ctx;
}

// Animates a number from its previous value to the new one.
export function useCountUp(target, duration = 700) {
  const [value, setValue] = useState(target);
  const fromRef = useRef(target);
  useEffect(() => {
    const from = fromRef.current;
    if (from === target || typeof window === 'undefined') {
      setValue(target);
      return undefined;
    }
    let raf;
    const start = performance.now();
    const tick = (now) => {
      const k = Math.min(1, (now - start) / duration);
      const eased = 1 - (1 - k) ** 3;
      setValue(from + (target - from) * eased);
      if (k < 1) raf = requestAnimationFrame(tick);
      else fromRef.current = target;
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      fromRef.current = target;
    };
  }, [target, duration]);
  return value;
}
