/**
 * INTROSPECT — simulated 28-day dataset (DEMO DATA).
 *
 * This stands in for what Health Connect, Android usage stats and Google
 * Calendar would provide. It is generated, not real, and is labelled as such
 * in the UI. The insight engine treats it exactly like real daily data.
 */
import { mulberry32, gaussian } from './stats';

export const HISTORY_DAYS = 28;
export const TODAY = new Date(2026, 10, 24); // 24 Nov 2026 — matches the dashboard
const SEED = 20261124;

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

export const fmtHours = (h) => {
  const total = Math.round(h * 60);
  const hh = Math.floor(total / 60);
  const mm = Math.abs(total % 60);
  return `${hh}h ${String(mm).padStart(2, '0')}m`;
};
export const fmtMins = (m) => `${Math.round(m)}m`;
export const fmtInt = (n) => Math.round(n).toLocaleString('en-IN');

// Metric definitions: which source they come from and which way is "better".
export const METRICS = {
  sleepHrs: { label: 'Sleep', unit: 'h', fmt: fmtHours, source: 'health', better: 'up', generic: { value: 8, text: '8h for everyone' } },
  deepSleepMins: { label: 'Deep sleep', unit: 'min', fmt: fmtMins, source: 'health', better: 'up' },
  steps: { label: 'Steps', unit: 'steps', fmt: fmtInt, source: 'health', better: 'up', generic: { value: 10000, text: '10,000 steps for everyone' } },
  exerciseMins: { label: 'Exercise', unit: 'min', fmt: fmtMins, source: 'health', better: 'up' },
  restingHR: { label: 'Resting HR', unit: 'bpm', fmt: (v) => `${Math.round(v)} bpm`, source: 'health', better: 'down' },
  screenHrs: { label: 'Screen time', unit: 'h', fmt: fmtHours, source: 'screen', better: 'down' },
  lateNightMins: { label: 'Late-night use', unit: 'min', fmt: fmtMins, source: 'screen', better: 'down' },
  pickups: { label: 'Pickups', unit: '', fmt: fmtInt, source: 'screen', better: 'down' },
  notifications: { label: 'Notifications', unit: '', fmt: fmtInt, source: 'screen', better: 'down' },
  calendarHrs: { label: 'Scheduled hours', unit: 'h', fmt: fmtHours, source: 'calendar', better: null },
};

export const SOURCES = {
  health: { label: 'Health Connect', short: 'Health', detail: 'Sleep, steps, exercise, heart rate' },
  screen: { label: 'Screen Time', short: 'Screen', detail: 'Usage, late-night use, pickups, notifications' },
  calendar: { label: 'Google Calendar', short: 'Calendar', detail: 'Busy hours only — never titles' },
};

/**
 * One simulated day. `mods` lets the Nudge Lab change behaviour
 * (e.g. less late-night phone use) and see what the same model produces.
 */
export function simulateDay(rand, { date, prevLate }, mods = {}) {
  const dow = date.getDay(); // 0 Sun … 6 Sat
  const weekend = dow === 0 || dow === 6;

  const calendarHrs = clamp(weekend ? 1 + gaussian(rand, 0.8) : 6.2 + gaussian(rand, 1.3), 0, 10);
  const busy = (calendarHrs - 4.5) / 2.5;

  const workoutChance = mods.workoutChance ?? clamp(0.6 - 0.18 * busy, 0.15, 0.9);
  const workout = rand() < workoutChance;
  const exerciseMins = workout ? clamp(42 + gaussian(rand, 12), 20, 75) : 0;

  let lateNightMins = clamp(48 + 22 * busy + (weekend ? 18 : 0) + gaussian(rand, 24), 5, 135);
  if (mods.lateFactor !== undefined) lateNightMins = clamp(lateNightMins * mods.lateFactor, 5, 135);

  const screenHrs = clamp(4.4 + (lateNightMins / 60) * 0.95 + (weekend ? 0.6 : 0) + gaussian(rand, 0.55), 2, 11);
  const sleepHrs = clamp(7.75 - 0.0165 * lateNightMins + 0.005 * exerciseMins + gaussian(rand, 0.32), 4.5, 9.5);
  const deepSleepMins = clamp(62 + 0.6 * exerciseMins - 0.07 * lateNightMins + gaussian(rand, 9), 30, 130);
  const steps = clamp(8300 - 24 * (prevLate ?? 50) + 45 * exerciseMins + (weekend ? -600 : 0) + gaussian(rand, 850), 2500, 16000);
  let pickups = clamp(54 + 0.26 * lateNightMins + gaussian(rand, 7), 25, 140);
  if (mods.pickupFactor !== undefined) pickups *= mods.pickupFactor;
  const notifications = clamp(132 + gaussian(rand, 22), 60, 240);
  const restingHR = clamp(63 - 1.4 * (sleepHrs - 7) + gaussian(rand, 1.1), 54, 76);

  return {
    calendarHrs, exerciseMins, workout, lateNightMins, screenHrs, sleepHrs,
    deepSleepMins, steps, pickups, notifications, restingHR,
  };
}

const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function dayLabel(date) {
  return `${DOW[date.getDay()]} ${date.getDate()}`;
}
export function longDate(date) {
  return `${DOW[date.getDay()]}, ${date.getDate()} ${MON[date.getMonth()]}`;
}

export function addDays(date, n) {
  const d = new Date(date);
  d.setDate(d.getDate() + n);
  return d;
}

// Builds the full 28-day history ending today.
export function buildDataset() {
  const rand = mulberry32(SEED);
  const days = [];
  let prevLate = 50;
  for (let i = HISTORY_DAYS - 1; i >= 0; i -= 1) {
    const date = addDays(TODAY, -i);
    const d = simulateDay(rand, { date, prevLate });
    days.push({ date, label: dayLabel(date), isToday: i === 0, ...d });
    prevLate = d.lateNightMins;
  }
  // Pin today to the values shown on the dashboard cards.
  Object.assign(days[days.length - 1], {
    sleepHrs: 6.75, steps: 8432, screenHrs: 6.53, lateNightMins: 75,
    pickups: 72, notifications: 146, restingHR: 64, exerciseMins: 0, workout: false,
    deepSleepMins: 72,
  });
  return days;
}

export const DATASET = buildDataset();
