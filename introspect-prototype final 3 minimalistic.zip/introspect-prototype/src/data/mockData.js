/**
 * INTROSPECT — Fixed Mock Data & Cross-Domain Metrics
 * Label: DEMO DATA (Ideathon Prototype)
 */

export const DEMO_USER = {
  name: "Alex Morgan",
  status: "Demo profile",
  period: "Today, Nov 24",
  syncStatus: "Sample data (no live sync)",
};

// 1. Core Health & Activity Metrics (Exact prompt values)
export const HEALTH_METRICS = [
  {
    id: "sleep",
    label: "Sleep Duration",
    value: "6h 45m",
    subtext: "Deep sleep: 1h 20m • REM: 1h 45m",
    target: "7h 30m target",
    delta: "-45m vs average",
    status: "warning", // warning | good | neutral
    icon: "Moon",
    color: "#8AA2BA",
    category: "Rest & Recovery",
  },
  {
    id: "steps",
    label: "Steps",
    value: "8,432",
    subtext: "Goal: 8,000 steps achieved",
    target: "105% of goal",
    delta: "+18% vs last week",
    status: "good",
    icon: "Footprints",
    color: "#BFA883",
    category: "Movement",
  },
  {
    id: "exercise",
    label: "Exercise",
    value: "4 workouts",
    subtext: "320 active mins this week",
    target: "Target: 4/week",
    delta: "Weekly target reached",
    status: "good",
    icon: "Flame",
    color: "#B98C3A",
    category: "Cardio & Fitness",
  },
  {
    id: "resting_heart_rate",
    label: "Resting Heart Rate",
    value: "64 BPM",
    subtext: "Normal baseline (62–68 BPM)",
    target: "Optimal range",
    delta: "Stable trend",
    status: "good",
    icon: "HeartPulse",
    color: "#CB7767",
    category: "Vitals",
  },
];

// 2. Digital Behaviour Metrics (Exact prompt values)
export const DIGITAL_METRICS = [
  {
    id: "screen_time",
    label: "Screen Time",
    value: "6h 32m",
    subtext: "Peak usage between 8 PM - 11 PM",
    target: "Daily limit: 4h 30m",
    delta: "+1h 12m vs 7-day avg",
    status: "warning",
    icon: "Smartphone",
    color: "#8AA2BA",
    category: "Screen Engagement",
  },
  {
    id: "most_used_app",
    label: "Most Used App",
    value: "Instagram",
    subtext: "2h 14m active engagement",
    target: "34% of screen time",
    delta: "Largest share of screen time",
    status: "warning",
    icon: "AppWindow",
    color: "#CB7767",
    category: "Social App",
  },
  {
    id: "pickups",
    label: "Phone Pickups",
    value: "72",
    subtext: "Avg 1 pickup every 14 mins awake",
    target: "First pickup: 7:12 AM",
    delta: "+14 vs yesterday",
    status: "neutral",
    icon: "HandMetal",
    color: "#BFA883",
    category: "Check Frequency",
  },
  {
    id: "notifications",
    label: "Notifications",
    value: "146",
    subtext: "82 social • 38 messaging • 26 system",
    target: "Top source: WhatsApp (58)",
    delta: "High interruption load",
    status: "neutral",
    icon: "BellRing",
    color: "#A7BACC",
    category: "Digital Load",
  },
  {
    id: "late_night_usage",
    label: "Late-Night Usage",
    value: "1h 15m",
    subtext: "After 11:00 PM in bed",
    target: "Recommended: 0m",
    delta: "Linked with shorter sleep",
    status: "alert",
    icon: "ShieldAlert",
    color: "#CB7767",
    category: "Pre-Sleep Digital",
  },
];

// 3. Behavioural Insights (Core differentiator connecting multiple data sources)
export const BEHAVIOURAL_INSIGHTS = [
  {
    id: "insight-screen-sleep",
    title: "Screen Time + Sleep Correlation",
    badge: "Cross-Domain Impact",
    badgeColor: "purple",
    connection: "Late-Night Screen (1h 15m) → Sleep Deficit (-45m)",
    summary: "Higher screen usage late at night is associated with shorter sleep duration.",
    explanation: "On nights with more than 45 minutes of screen use after 11:00 PM, your sleep averaged 6h 15m, compared with 7h 40m on other nights. This is an association in sample data, not proof that the phone caused it.",
    recommendation: "Activate phone Downtime at 10:30 PM. Swap the final 30 minutes before bed with reading or a non-screen wind-down routine and see whether your sleep changes over the next week.",
    dataSources: ["Screen Time", "Sleep Sensor", "Late-Night App Logs"],
    impactLevel: "High Impact",
    stat: "-1.2 hrs sleep on high late-screen nights",
  },
  {
    id: "insight-exercise-sleep",
    title: "Exercise + Sleep Synergy",
    badge: "Recovery Pattern",
    badgeColor: "emerald",
    connection: "Workout Days → Longer Deep Sleep",
    summary: "Days with exercise tend to show longer deep sleep in this sample.",
    explanation: "When you complete at least 30 minutes of aerobic or resistance training before 6:30 PM, your deep sleep is about 34 minutes longer on average and you wake up less often.",
    recommendation: "Keep up your current 4x weekly workout pace. For optimal recovery, try to schedule vigorous sessions at least 3 hours before bedtime and check whether the pattern holds.",
    dataSources: ["Physical Activity", "Heart Rate Monitor", "Sleep Tracker"],
    impactLevel: "Positive Reinforcement",
    stat: "+34m deep sleep (sample data)",
  },
  {
    id: "insight-digital-peak",
    title: "Digital Behaviour Concentration",
    badge: "Habit Distribution",
    badgeColor: "cyan",
    connection: "Time of Day (8 PM–11 PM) → 54% of Screen Intake",
    summary: "Your phone usage is highest between 8 PM and 11 PM.",
    explanation: "Over 3h 30m of total daily screen time is clustered in the three hours before bed, driven by passive video scrolling on Instagram and messaging apps. This matches your lowest physical movement window.",
    recommendation: "Set a 45-minute social media app limit starting at 8:30 PM. Placing your phone charging station across the room can break the reflexive pickup loop.",
    dataSources: ["App Usage Tracker", "Hourly Pickup Logs"],
    impactLevel: "Actionable Routine",
    stat: "54% daily screentime in 3 evening hours",
  },
  {
    id: "insight-activity-trend",
    title: "Activity Momentum",
    badge: "Weekly Milestone",
    badgeColor: "blue",
    connection: "7-Day Cumulative Steps → 18% Net Increase",
    summary: "Your steps have increased by 18% compared to last week.",
    explanation: "You averaged 8,432 steps today versus 7,140 steps during the same weekday last week. This increase is primarily driven by morning commutes and a consistent post-lunch walk.",
    recommendation: "Maintain your 15-minute afternoon walking block—it directly correlates with sustained focus and reduced afternoon screen pickups.",
    dataSources: ["Pedometer", "Movement Sensors"],
    impactLevel: "Milestone Achieved",
    stat: "+1,292 steps daily delta",
  },
];

// 4. Cross-Domain Intelligence Comparison Graphs Data

// Graph 1: Screen Time vs Sleep Duration across 7 days
export const SCREEN_VS_SLEEP_DATA = [
  { day: "Mon", screenTime: 4.8, sleepDuration: 7.8, lateNightScreen: 0.3 },
  { day: "Tue", screenTime: 5.2, sleepDuration: 7.5, lateNightScreen: 0.5 },
  { day: "Wed", screenTime: 7.1, sleepDuration: 6.2, lateNightScreen: 1.4 },
  { day: "Thu", screenTime: 4.9, sleepDuration: 7.7, lateNightScreen: 0.4 },
  { day: "Fri", screenTime: 7.6, sleepDuration: 5.9, lateNightScreen: 1.8 },
  { day: "Sat", screenTime: 6.8, sleepDuration: 6.5, lateNightScreen: 1.3 },
  { day: "Sun (Today)", screenTime: 6.53, sleepDuration: 6.75, lateNightScreen: 1.25 },
];

// Graph 2: Exercise vs Sleep Quality / Duration
export const EXERCISE_VS_SLEEP_DATA = [
  { day: "Mon", exerciseMins: 45, sleepDuration: 7.8, deepSleepMins: 95, workout: "Running" },
  { day: "Tue", exerciseMins: 0, sleepDuration: 7.5, deepSleepMins: 65, workout: "Rest" },
  { day: "Wed", exerciseMins: 50, sleepDuration: 7.6, deepSleepMins: 102, workout: "Gym / Strength" },
  { day: "Thu", exerciseMins: 0, sleepDuration: 6.8, deepSleepMins: 58, workout: "Rest" },
  { day: "Fri", exerciseMins: 35, sleepDuration: 7.4, deepSleepMins: 88, workout: "Cycling" },
  { day: "Sat", exerciseMins: 60, sleepDuration: 8.1, deepSleepMins: 110, workout: "HIIT Workout" },
  { day: "Sun (Today)", exerciseMins: 0, sleepDuration: 6.75, deepSleepMins: 72, workout: "Rest" },
];

// Graph 3: Late-Night Phone Usage vs Next-Day Physical Activity (Steps)
export const LATE_PHONE_VS_STEPS_DATA = [
  { day: "Mon", lateNightUsageMins: 18, nextDaySteps: 9400, fatigueLevel: "Low" },
  { day: "Tue", lateNightUsageMins: 30, nextDaySteps: 8850, fatigueLevel: "Low" },
  { day: "Wed", lateNightUsageMins: 84, nextDaySteps: 6120, fatigueLevel: "High" },
  { day: "Thu", lateNightUsageMins: 22, nextDaySteps: 9100, fatigueLevel: "Low" },
  { day: "Fri", lateNightUsageMins: 108, nextDaySteps: 5800, fatigueLevel: "High" },
  { day: "Sat", lateNightUsageMins: 78, nextDaySteps: 7200, fatigueLevel: "Medium" },
  { day: "Sun (Today)", lateNightUsageMins: 75, nextDaySteps: 8432, fatigueLevel: "Moderate" },
];

// App Usage Breakdown
export const APP_USAGE_BREAKDOWN = [
  { name: "Instagram", minutes: 134, percent: 34, color: "#CB7767" },
  { name: "YouTube", minutes: 86, percent: 22, color: "#B35D4D" },
  { name: "WhatsApp", minutes: 74, percent: 19, color: "#86A87E" },
  { name: "Chrome", minutes: 52, percent: 13, color: "#6F89A3" },
  { name: "Others", minutes: 46, percent: 12, color: "#6F89A3" },
];

// Daily Summary text (Prompt requirement)
export const DAILY_SUMMARY_TEXT = {
  title: "Your Day at a Glance",
  overview: "Your physical activity was above average today, but your screen time was higher than usual. Your late-night phone usage may be affecting your sleep consistency.",
  highlights: [
    { label: "Physical Activity", status: "Above Average (+18%)", icon: "TrendingUp", color: "emerald" },
    { label: "Screen Time", status: "Elevated (6h 32m)", icon: "AlertTriangle", color: "amber" },
    { label: "Sleep Consistency", status: "Affected by late screen (-45m)", icon: "Moon", color: "purple" },
  ],
  score: 74,
  scoreLabel: "Harmony Index",
};

// Architecture / Ideathon Concept Pillars
export const CONCEPT_PILLARS = [
  {
    step: "01",
    tag: "Collect",
    title: "Aggregates Existing Device Signals",
    description: "Connects health sensors (Apple Health/Google Fit, smartbands) with digital screen metrics (Screen Time, App usage, pickups, notifications) without new hardware.",
    icon: "Layers",
    color: "#BFA883",
  },
  {
    step: "02",
    tag: "Understand",
    title: "Finds Cross-Domain Links",
    description: "Instead of treating health and phone habits in isolated silos, Introspect looks for links between them (e.g. late screen habits and shorter sleep), and says how strong the evidence is.",
    icon: "Network",
    color: "#8AA2BA",
  },
  {
    step: "03",
    tag: "Act",
    title: "Delivers Contextual Micro-Actions",
    description: "Translates abstract metrics into actionable micro-interventions (e.g., automated downtime suggestions, pre-sleep routines, and optimal exercise windows).",
    icon: "Sparkles",
    color: "#CB7767",
  },
];
