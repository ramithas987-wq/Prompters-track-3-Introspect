import React, { useState } from 'react';
import { FileText, TrendingUp, TrendingDown, Minus, Lightbulb, HelpCircle, Copy, Check, Link2, ArrowRight } from 'lucide-react';
import { useEngine } from '../../engine/EngineContext';
import { METRICS, SOURCES, longDate } from '../../engine/dataset';
import { NUDGES, CONFIDENCE } from '../../engine/engine';
import { SectionTitle, HonestyNote, ConfidenceBadge } from './shared';

const ROWS = ['sleepHrs', 'deepSleepMins', 'steps', 'exerciseMins', 'screenHrs', 'lateNightMins', 'pickups', 'restingHR'];

function Trend({ z, better }) {
  if (Math.abs(z) < 0.3) return <Minus className="w-4 h-4 text-slate-500" />;
  const good = better ? (better === 'up') === z > 0 : null;
  const cls = good === null ? 'text-slate-300' : good ? 'text-emerald-400' : 'text-rose-400';
  return z > 0 ? <TrendingUp className={`w-4 h-4 ${cls}`} /> : <TrendingDown className={`w-4 h-4 ${cls}`} />;
}

export default function WeeklyReport({ onOpenNudges }) {
  const { result, sources } = useEngine();
  const [copied, setCopied] = useState(false);
  const w = result.weekly;

  if (!w) {
    return (
      <section className="mb-12">
        <SectionTitle icon={FileText} kicker="Every Sunday" title="Weekly Report" />
        <div className="pop-in rounded-2xl border border-sky-500/30 bg-sky-500/5 p-8 text-center text-sm text-sky-200">
          A weekly report needs this week plus at least one earlier week to compare against. Switch the history window to 14 or 28 days.
        </div>
      </section>
    );
  }

  const visible = ROWS.filter((k) => sources[METRICS[k].source]);
  const found = result.tests.filter((t) => t.confidence === 'strong' || t.confidence === 'moderate').sort((a, b) => (b.domain === 'cross') - (a.domain === 'cross') || Math.abs(b.r) - Math.abs(a.r));
  const unsure = result.tests.filter((t) => t.confidence === 'none' || t.confidence === 'insufficient');
  const top = found[0];
  const nudge = top ? NUDGES.find((n) => n.basedOn === top.id && n.requires.every((s) => sources[s])) || NUDGES.find((n) => n.requires.every((s) => sources[s]) && result.testsById[n.basedOn].confidence !== 'none') : null;

  const lines = visible.map((k) => {
    const v = w.metrics[k];
    const m = METRICS[k];
    return `${m.label}: ${m.fmt(v.week)} avg (normal ${m.fmt(v.before)})`;
  });
  const summaryText = [
    `INTROSPECT weekly report, ${longDate(w.weekStart)} – ${longDate(w.weekEnd)} (sample data)`,
    ...lines,
    top ? `Strongest link: ${top.title} (r = ${top.r.toFixed(2)}, ${CONFIDENCE[top.confidence].label.toLowerCase()})` : 'No clear links this week.',
    nudge ? `Try next: ${nudge.title}` : '',
  ].filter(Boolean).join('\n');

  const copy = () => {
    try {
      navigator.clipboard.writeText(summaryText);
    } catch (e) {
      /* clipboard may be blocked; ignore */
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const sleep = w.metrics.sleepHrs;
  const headline = sources.health
    ? `You slept ${METRICS.sleepHrs.fmt(sleep.week)} a night on average this week, ${Math.abs(sleep.z) < 0.3 ? 'about your normal' : sleep.z > 0 ? 'more than your normal' : 'less than your normal'} of ${METRICS.sleepHrs.fmt(sleep.before)}.`
    : 'Health data is switched off, so this report covers phone use only.';

  return (
    <section className="mb-12">
      <SectionTitle
        icon={FileText}
        kicker="What a user reads every Sunday"
        title="Weekly Report"
        subtitle="This week vs your normal."
        right={(
          <button onClick={copy} className="self-start flex items-center gap-2 px-3.5 py-2 rounded-xl bg-surface-card border border-surface-border hover:border-purple-500/40 text-xs text-slate-200 transition-all active:scale-95">
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-purple-300" />}
            {copied ? 'Copied' : 'Copy as text'}
          </button>
        )}
      />

      <div className="rounded-3xl border border-surface-border bg-surface-card p-5 sm:p-8 relative overflow-hidden">
        <div className="relative">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
            <span className="text-[11px] font-mono text-slate-400">{longDate(w.weekStart)} – {longDate(w.weekEnd)} · compared with the {w.baselineDays} days before</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-700/60 text-slate-400">SAMPLE DATA</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-white leading-snug max-w-3xl">{headline}</h3>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 mt-6">
            {/* Metrics table */}
            <div className="lg:col-span-7 rounded-2xl bg-surface-card/80 border border-surface-border overflow-hidden">
              <div className="grid grid-cols-12 px-4 py-2.5 text-[10px] uppercase tracking-wider text-slate-500 font-semibold border-b border-surface-border">
                <div className="col-span-4">Metric</div>
                <div className="col-span-3 text-right">This week</div>
                <div className="col-span-3 text-right">Your normal</div>
                <div className="col-span-2 text-right">Trend</div>
              </div>
              <div className="stagger">
                {visible.map((k) => {
                  const v = w.metrics[k];
                  const m = METRICS[k];
                  return (
                    <div key={k} className="grid grid-cols-12 items-center px-4 py-2.5 text-xs border-b border-surface-border/50 last:border-0 hover:bg-surface-hover/50 transition-colors">
                      <div className="col-span-4 text-slate-300">{m.label}</div>
                      <div className="col-span-3 text-right font-mono text-white">{m.fmt(v.week)}</div>
                      <div className="col-span-3 text-right font-mono text-slate-400">{m.fmt(v.before)}</div>
                      <div className="col-span-2 flex justify-end"><Trend z={v.z} better={m.better} /></div>
                    </div>
                  );
                })}
              </div>
              {visible.length < ROWS.length && (
                <div className="px-4 py-2 text-[11px] text-rose-300/80 bg-rose-500/5 border-t border-rose-500/20">
                  Some metrics are hidden because {Object.entries(sources).filter(([, on]) => !on).map(([k]) => SOURCES[k].label).join(' and ')} is switched off.
                </div>
              )}
            </div>

            {/* Findings */}
            <div className="lg:col-span-5 space-y-4">
              <div className="rounded-2xl bg-purple-950/20 border border-purple-500/30 p-4">
                <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-purple-300 mb-2">
                  <Link2 className="w-3.5 h-3.5" /> Strongest link found
                </div>
                {top ? (
                  <>
                    <div className="flex items-center justify-between gap-2">
                      <div className="text-sm font-semibold text-white">{top.title}</div>
                      <ConfidenceBadge confidence={top.confidence} />
                    </div>
                    <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">{top.sentence}</p>
                    <div className="text-[10px] font-mono text-slate-500 mt-1">r = {top.r.toFixed(2)} · p = {top.p < 0.001 ? '< 0.001' : top.p.toFixed(3)} · {top.n} days</div>
                  </>
                ) : (
                  <p className="text-xs text-slate-400">No clear links with the current data and sources.</p>
                )}
              </div>

              <div className="rounded-2xl bg-pink-950/20 border border-pink-500/30 p-4">
                <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-pink-300 mb-2">
                  <Lightbulb className="w-3.5 h-3.5" /> One thing to try
                </div>
                {nudge ? (
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-semibold text-white">{nudge.title}</div>
                    </div>
                    <button onClick={onOpenNudges} className="shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-lg bg-pink-600/25 hover:bg-pink-600/40 border border-pink-500/40 text-pink-100 text-[11px] font-semibold transition-colors">
                      Try it <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">No suggestion this week. Introspect only suggests changes backed by a link.</p>
                )}
              </div>

              <div className="rounded-2xl bg-surface-card/80 border border-surface-border p-4">
                <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-2">
                  <HelpCircle className="w-3.5 h-3.5" /> What we're not sure about
                </div>
                <ul className="space-y-1">
                  {unsure.slice(0, 4).map((t) => (
                    <li key={t.id} className="text-[11px] text-slate-400 flex items-start gap-1.5">
                      <span className="mt-1.5 w-1 h-1 rounded-full bg-slate-500 shrink-0" />
                      <span><span className="text-slate-300">{t.title}</span>: {CONFIDENCE[t.confidence].label.toLowerCase()}</span>
                    </li>
                  ))}
                  {!unsure.length && <li className="text-[11px] text-slate-500">Nothing uncertain this week.</li>}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4">
        <HonestyNote>Green = better for you, red = worse.</HonestyNote>
      </div>
    </section>
  );
}
