import React, { useState } from 'react';
import { ResponsiveContainer, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ZAxis } from 'recharts';
import { ChevronDown, Lock } from 'lucide-react';
import { useEngine } from '../../engine/EngineContext';
import { METRICS, SOURCES } from '../../engine/dataset';
import { MIN_DAYS_FOR_LINKS } from '../../engine/engine';
import { ConfidenceBadge, CountUp } from './shared';

const FILTERS = [
  { id: 'all', label: 'All' },
  { id: 'found', label: 'Links' },
  { id: 'none', label: 'No link' },
];

const dotColor = (c) => (c === 'strong' ? '#86A87E' : c === 'moderate' ? '#D2A650' : '#7F7973');
const isFound = (t) => t.confidence === 'strong' || t.confidence === 'moderate';

// Short one-liner per test (the long sentence lives in the expanded view)
function summary(t) {
  if (t.locked) return `Needs ${t.requires.map((s) => SOURCES[s].short).join(' + ')}`;
  if (t.confidence === 'insufficient') return `Only ${t.n} days, need ${MIN_DAYS_FOR_LINKS}`;
  if (t.confidence === 'none') return 'No clear pattern';
  return `${t.hits} of ${t.highCount} days · ${t.effectText}`;
}

function ScatterTip({ active, payload, test }) {
  if (!active || !payload || !payload.length) return null;
  const pt = payload[0].payload;
  return (
    <div className="bg-[#1C1B18] border border-surface-border px-2.5 py-1.5 rounded-md text-[11px] font-mono">
      {METRICS[test.x].fmt(pt.x)} → {METRICS[test.y].fmt(pt.y)}
    </div>
  );
}

function Row({ test, open, onToggle }) {
  const canOpen = !test.locked;
  return (
    <div className={`border-b border-surface-border last:border-0 ${test.locked ? 'opacity-60' : ''}`}>
      <button
        onClick={canOpen ? onToggle : undefined}
        className={`w-full flex items-center gap-4 px-5 py-4 text-left transition-colors ${canOpen ? 'hover:bg-surface-hover/60' : 'cursor-default'}`}
      >
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium text-white truncate">{test.title}</div>
          <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-1.5">
            {test.locked && <Lock className="w-3 h-3" />}
            {summary(test)}
          </div>
        </div>
        {!test.locked && test.confidence !== 'insufficient' && (
          <CountUp
            value={test.r}
            format={(v) => (v >= 0 ? '+' : '−') + Math.abs(v).toFixed(2)}
            className={`w-14 text-right font-mono text-sm ${isFound(test) ? 'text-white' : 'text-slate-500'}`}
          />
        )}
        <div className="w-36 flex justify-end">
          <ConfidenceBadge confidence={test.confidence} />
        </div>
        <ChevronDown className={`w-4 h-4 text-slate-500 transition-transform duration-300 ${open ? 'rotate-180' : ''} ${canOpen ? '' : 'invisible'}`} />
      </button>

      <div className={`expand ${open && canOpen ? 'open' : ''}`}>
        <div>
          <div className="px-5 pb-5 grid grid-cols-1 md:grid-cols-5 gap-5 items-center">
            <div className="md:col-span-3 h-48">
              {open && canOpen && (
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2A2825" />
                    <XAxis type="number" dataKey="x" stroke="#7F7973" tick={{ fontSize: 10 }} domain={['auto', 'auto']}
                      tickFormatter={(v) => (METRICS[test.x].unit === 'h' ? `${v.toFixed(1)}h` : Math.round(v))} />
                    <YAxis type="number" dataKey="y" stroke="#7F7973" tick={{ fontSize: 10 }} domain={['auto', 'auto']}
                      tickFormatter={(v) => (METRICS[test.y].unit === 'h' ? `${v.toFixed(1)}h` : Math.round(v))} />
                    <ZAxis range={[45, 45]} />
                    <Tooltip content={<ScatterTip test={test} />} cursor={{ strokeDasharray: '3 3', stroke: '#57534E' }} />
                    <Scatter data={test.points} fill={dotColor(test.confidence)} fillOpacity={0.85} animationDuration={600} />
                  </ScatterChart>
                </ResponsiveContainer>
              )}
            </div>
            <div className="md:col-span-2 space-y-3">
              <p className="text-sm text-slate-300 leading-relaxed">{test.sentence}</p>
              {test.confidence !== 'insufficient' && (
                <div className="text-[11px] font-mono text-slate-500">
                  r {test.r.toFixed(2)} · p {test.p < 0.001 ? '< 0.001' : test.p.toFixed(3)} · {test.n} days
                </div>
              )}
              <div className="text-[11px] text-slate-500">Each dot is one day.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function LinkTests() {
  const { result } = useEngine();
  const [filter, setFilter] = useState('all');
  const [openId, setOpenId] = useState(null);

  const tests = result.tests.filter((t) => {
    if (filter === 'found') return isFound(t);
    if (filter === 'none') return !isFound(t);
    return true;
  });
  const found = result.tests.filter(isFound).length;

  return (
    <section className="mb-12">
      <div className="flex items-end justify-between gap-4 mb-5">
        <div>
          <h2 className="text-2xl font-semibold text-white">Insights</h2>
          <p className="text-sm text-slate-500 mt-1">
            {found} of 8 possible links found in your last {result.windowDays} days.
          </p>
        </div>
        <div className="flex p-1 bg-surface-card rounded-lg border border-surface-border">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`px-3 py-1 rounded-md text-xs transition-colors ${filter === f.id ? 'bg-surface-hover text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div key={filter} className="rounded-xl bg-surface-card border border-surface-border overflow-hidden stagger">
        {tests.map((t) => (
          <Row key={t.id} test={t} open={openId === t.id} onToggle={() => setOpenId(openId === t.id ? null : t.id)} />
        ))}
        {!tests.length && <div className="px-5 py-8 text-sm text-slate-500 text-center">Nothing here.</div>}
      </div>

      <p className="text-xs text-slate-500 mt-3">Links show association, not cause.</p>
    </section>
  );
}
