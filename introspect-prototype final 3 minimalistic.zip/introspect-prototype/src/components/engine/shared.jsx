import React from 'react';
import { Lock, ShieldCheck, Info } from 'lucide-react';
import { CONFIDENCE } from '../../engine/engine';
import { SOURCES } from '../../engine/dataset';
import { useEngine, useCountUp } from '../../engine/EngineContext';

const TONES = {
  emerald: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/35',
  amber: 'bg-amber-500/15 text-amber-300 border-amber-500/35',
  slate: 'bg-slate-500/15 text-slate-300 border-slate-500/35',
  sky: 'bg-sky-500/15 text-sky-300 border-sky-500/35',
  rose: 'bg-rose-500/15 text-rose-300 border-rose-500/35',
  purple: 'bg-purple-500/15 text-purple-300 border-purple-500/35',
  cyan: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/35',
};

export function Pill({ tone = 'slate', children, className = '' }) {
  return (
    <span className={`inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border ${TONES[tone]} ${className}`}>
      {children}
    </span>
  );
}

export function ConfidenceBadge({ confidence }) {
  const c = CONFIDENCE[confidence] || CONFIDENCE.none;
  return (
    <Pill tone={c.tone}>
      <span className={`w-1.5 h-1.5 rounded-full ${confidence === 'strong' ? 'bg-emerald-400 animate-pulse' : 'bg-current opacity-70'}`} />
      {c.label}
    </Pill>
  );
}

/** Animated number. `format` turns the in-between value into text. */
export function CountUp({ value, format = (v) => v.toFixed(0), className = '' }) {
  const v = useCountUp(value);
  return <span className={className}>{format(v)}</span>;
}

/** Correlation meter: −1 on the left, +1 on the right, marker slides to r. */
export function RMeter({ r, confidence }) {
  const pos = ((r + 1) / 2) * 100;
  const color = confidence === 'strong' ? '#86A87E' : confidence === 'moderate' ? '#D2A650' : '#7F7973';
  return (
    <div className="w-full">
      <div className="relative h-2 rounded-full bg-slate-700/60">
        <div className="absolute top-1/2 left-1/2 w-px h-3 -translate-y-1/2 bg-slate-500" />
        <div
          className="absolute top-1/2 w-3.5 h-3.5 -translate-y-1/2 -translate-x-1/2 rounded-full border-2 border-[#151412] transition-all duration-700 ease-out"
          style={{ left: `${pos}%`, backgroundColor: color, boxShadow: `0 0 12px ${color}88` }}
        />
      </div>
      <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1">
        <span>−1 opposite</span>
        <span>0 none</span>
        <span>+1 together</span>
      </div>
    </div>
  );
}

/** Covers a block when the data source it needs is switched off. */
export function SourceLock({ requires, children, compact = false }) {
  const { sources, toggleSource } = useEngine();
  const missing = requires.filter((s) => !sources[s]);
  const locked = missing.length > 0;
  return (
    <div className="relative h-full">
      <div className={`h-full transition-all duration-500 ${locked ? 'blur-[5px] opacity-30 pointer-events-none select-none' : ''}`}>{children}</div>
      {locked && (
        <div className="absolute inset-0 z-10 flex items-center justify-center pop-in">
          <div className={`text-center rounded-2xl bg-[#151412]/90 border border-rose-500/30 shadow-card ${compact ? 'px-4 py-3' : 'px-6 py-5'} max-w-xs`}>
            <div className="mx-auto w-9 h-9 rounded-full bg-rose-500/15 border border-rose-500/30 flex items-center justify-center mb-2">
              <Lock className="w-4 h-4 text-rose-300" />
            </div>
            <div className="text-sm font-medium text-white">{missing.map((m) => SOURCES[m].label).join(' + ')} is off</div>
            <div className="flex flex-wrap justify-center gap-1.5 mt-3">
              {missing.map((m) => (
                <button
                  key={m}
                  onClick={() => toggleSource(m)}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-purple-600/25 hover:bg-purple-600/40 text-purple-200 border border-purple-500/40 transition-colors"
                >
                  Connect {SOURCES[m].short}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function SectionTitle({ title, subtitle, right }) {
  return (
    <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-5">
      <div>
        <h2 className="text-2xl font-semibold text-white">{title}</h2>
        {subtitle && <p className="text-sm text-slate-500 mt-1">{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

export function HonestyNote({ children }) {
  return <p className="text-xs text-slate-500">{children}</p>;
}

export function InfoTip({ text }) {
  return (
    <span className="relative group inline-flex">
      <Info className="w-3.5 h-3.5 text-slate-500 hover:text-slate-300 cursor-help" />
      <span className="pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-56 rounded-lg bg-[#1C1B18] border border-surface-border px-3 py-2 text-[11px] leading-snug text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity z-30 shadow-card normal-case tracking-normal font-normal">
        {text}
      </span>
    </span>
  );
}
