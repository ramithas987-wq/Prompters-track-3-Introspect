import React, { useMemo, useState } from 'react';
import { ResponsiveContainer, ComposedChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceArea, ReferenceLine } from 'recharts';
import { Target, Moon, Footprints, Smartphone, Clock3, HandMetal, HeartPulse } from 'lucide-react';
import { useEngine } from '../../engine/EngineContext';
import { METRICS, longDate } from '../../engine/dataset';
import { mean, sd } from '../../engine/stats';
import { SectionTitle, SourceLock, HonestyNote, CountUp } from './shared';

const CHOICES = [
  { key: 'sleepHrs', icon: Moon },
  { key: 'steps', icon: Footprints },
  { key: 'screenHrs', icon: Smartphone },
  { key: 'lateNightMins', icon: Clock3 },
  { key: 'pickups', icon: HandMetal },
  { key: 'restingHR', icon: HeartPulse },
];

// Colour a day by how far it is from the personal average, in the "better/worse" direction.
function cellStyle(z, better) {
  const good = better === 'down' ? -z : z;
  const a = Math.min(1, Math.abs(good) / 2);
  if (Math.abs(good) < 0.35) return { backgroundColor: 'rgba(127, 121, 115,0.22)', borderColor: 'rgba(127, 121, 115,0.35)' };
  return good > 0
    ? { backgroundColor: `rgba(108, 143, 100,${0.15 + a * 0.55})`, borderColor: `rgba(134, 168, 126,${0.3 + a * 0.4})` }
    : { backgroundColor: `rgba(179, 93, 77,${0.15 + a * 0.55})`, borderColor: `rgba(203, 119, 103,${0.3 + a * 0.4})` };
}

function describe(z, better) {
  const a = Math.abs(z);
  if (a < 0.35) return 'within your normal range';
  const dir = z > 0 ? 'above' : 'below';
  const size = a >= 1.5 ? 'well ' : a >= 0.75 ? '' : 'slightly ';
  const tone = better ? ((better === 'up') === (z > 0) ? ' (better than usual)' : ' (worse than usual)') : '';
  return `${size}${dir} your normal${tone}`;
}

export default function BaselineView() {
  const { result } = useEngine();
  const [metricKey, setMetricKey] = useState('sleepHrs');
  const [hover, setHover] = useState(null);
  const m = METRICS[metricKey];
  const rows = result.rows;

  const { avg, dev, cells, chart } = useMemo(() => {
    const hist = rows.slice(0, -1).map((d) => d[metricKey]);
    const a = mean(hist);
    const s = sd(hist) || 1;
    return {
      avg: a,
      dev: s,
      cells: rows.map((d) => ({ ...d, v: d[metricKey], z: (d[metricKey] - a) / s })),
      chart: rows.map((d) => ({ label: d.label, v: Number(d[metricKey].toFixed(2)) })),
    };
  }, [rows, metricKey]);

  const today = cells[cells.length - 1];
  const focus = hover || today;
  const pad = (cells[0].date.getDay() + 6) % 7; // Monday-first grid
  const lo = avg - dev;
  const hi = avg + dev;
  const generic = m.generic;
  const scaleMin = Math.min(lo - dev, today.v, generic ? generic.value : Infinity);
  const scaleMax = Math.max(hi + dev, today.v, generic ? generic.value : -Infinity);
  const pct = (v) => `${((v - scaleMin) / (scaleMax - scaleMin)) * 100}%`;

  return (
    <section className="mb-12">
      <SectionTitle
        icon={Target}
        kicker="Personal baselines"
        tone="cyan"
        title="Your Normal"
        subtitle="Each day compared with your own usual range."
      />

      {/* Metric chips */}
      <div className="flex flex-wrap gap-2 mb-5">
        {CHOICES.map(({ key, icon: Icon }) => (
          <button
            key={key}
            onClick={() => { setMetricKey(key); setHover(null); }}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all duration-300 active:scale-95 ${
              metricKey === key ? 'bg-cyan-500/15 border-cyan-400/50 text-cyan-100 shadow-cyanGlow' : 'bg-surface-card border-surface-border text-slate-400 hover:text-slate-200 hover:border-slate-600'
            }`}
          >
            <Icon className="w-3.5 h-3.5" />
            {METRICS[key].label}
          </button>
        ))}
      </div>

      <SourceLock requires={[m.source]}>
        <div key={metricKey + result.windowDays} className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Calendar heat-grid */}
          <div className="lg:col-span-7 rounded-2xl bg-surface-card border border-surface-border p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-white">Last {rows.length} days: {m.label.toLowerCase()} vs your normal</h3>
              <div className="flex items-center gap-2 text-[10px] text-slate-400">
                <span className="w-3 h-3 rounded bg-rose-500/60" /> worse
                <span className="w-3 h-3 rounded bg-slate-500/30 ml-1" /> normal
                <span className="w-3 h-3 rounded bg-emerald-500/60 ml-1" /> better
              </div>
            </div>
            <div className="grid grid-cols-7 gap-2 text-[10px] text-slate-500 font-mono mb-2">
              {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => <div key={d} className="text-center">{d}</div>)}
            </div>
            <div className="grid grid-cols-7 gap-2" onMouseLeave={() => setHover(null)}>
              {Array.from({ length: pad }).map((_, i) => <div key={`p${i}`} />)}
              {cells.map((c, i) => (
                <button
                  key={c.label + i}
                  onMouseEnter={() => setHover(c)}
                  onFocus={() => setHover(c)}
                  className={`cell-in aspect-square rounded-lg border flex flex-col items-center justify-center transition-transform duration-200 hover:scale-110 hover:z-10 ${c.isToday ? 'ring-2 ring-purple-400 ring-offset-2 ring-offset-[#1A1917]' : ''}`}
                  style={{ ...cellStyle(c.z, m.better), animationDelay: `${i * 18}ms` }}
                >
                  <span className="text-[11px] font-bold text-white/90">{c.date.getDate()}</span>
                  <span className="text-[9px] font-mono text-white/60 hidden sm:block">{m.unit === 'h' ? c.v.toFixed(1) : Math.round(c.v)}</span>
                </button>
              ))}
            </div>
            <div className="mt-4 rounded-xl bg-[#161513] border border-surface-border px-4 py-3 text-xs text-slate-300 min-h-[52px]">
              <span className="font-mono text-slate-400">{focus.isToday ? 'Today' : longDate(focus.date)}:</span>{' '}
              <span className="text-white font-semibold">{m.fmt(focus.v)}</span>, {describe(focus.z, m.better)}
              <span className="text-slate-500"> ({focus.z >= 0 ? '+' : '−'}{Math.abs(focus.z).toFixed(1)} SD)</span>
            </div>
          </div>

          {/* Today vs normal vs generic target */}
          <div className="lg:col-span-5 space-y-5">
            <div className="rounded-2xl bg-surface-card border border-surface-border p-5">
              <h3 className="text-sm font-semibold text-white mb-1">Today vs your normal</h3>
              <p className="text-[11px] text-slate-500 mb-5">Normal = your average ± 1 SD</p>
              <div className="relative h-16">
                <div className="absolute top-7 left-0 right-0 h-2 rounded-full bg-slate-800" />
                <div className="absolute top-7 h-2 rounded-full bg-cyan-500/40 border border-cyan-400/50 transition-all duration-700" style={{ left: pct(lo), width: `calc(${pct(hi)} - ${pct(lo)})` }} />
                <div className="absolute top-0 -translate-x-1/2 transition-all duration-700 text-center" style={{ left: pct(today.v) }}>
                  <div className="text-[10px] font-bold text-purple-200 whitespace-nowrap">Today</div>
                  <div className="mx-auto mt-1 w-4 h-4 rounded-full bg-purple-400 border-2 border-[#1A1917] shadow-glow" />
                </div>
                {generic && (
                  <div className="absolute top-[22px] -translate-x-1/2 text-center transition-all duration-700" style={{ left: pct(generic.value) }}>
                    <div className="mx-auto w-0.5 h-5 bg-amber-400" />
                    <div className="text-[10px] text-amber-300 whitespace-nowrap mt-1">generic target</div>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-3 gap-2 mt-4 text-center">
                <div className="rounded-lg bg-[#161513] border border-surface-border py-2">
                  <div className="text-[10px] text-slate-500 uppercase tracking-wider">Today</div>
                  <div className="text-sm font-bold font-mono text-purple-200">{m.fmt(today.v)}</div>
                </div>
                <div className="rounded-lg bg-[#161513] border border-surface-border py-2">
                  <div className="text-[10px] text-slate-500 uppercase tracking-wider">Your normal</div>
                  <div className="text-sm font-bold font-mono text-cyan-200"><CountUp value={avg} format={m.fmt} /></div>
                </div>
                <div className="rounded-lg bg-[#161513] border border-surface-border py-2">
                  <div className="text-[10px] text-slate-500 uppercase tracking-wider">Range ±</div>
                  <div className="text-sm font-bold font-mono text-slate-200"><CountUp value={dev} format={m.fmt} /></div>
                </div>
              </div>
              {generic && (
                <p className="text-[11px] text-slate-500 mt-3">
                  Generic target <span className="text-amber-300">{m.fmt(generic.value)}</span> · yours <span className="text-cyan-200">{m.fmt(avg)}</span>
                </p>
              )}
            </div>

            <div className="rounded-2xl bg-surface-card border border-surface-border p-4 h-48">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={chart} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2A2825" vertical={false} />
                  <XAxis dataKey="label" stroke="#7F7973" tick={{ fontSize: 9 }} interval={Math.max(0, Math.floor(chart.length / 7) - 1)} />
                  <YAxis stroke="#7F7973" tick={{ fontSize: 9 }} domain={['auto', 'auto']} />
                  <Tooltip contentStyle={{ background: '#1C1B18', border: '1px solid #2E2C28', borderRadius: 10, fontSize: 11 }} formatter={(v) => [m.fmt(v), m.label]} />
                  <ReferenceArea y1={lo} y2={hi} fill="#BFA883" fillOpacity={0.12} stroke="none" />
                  <ReferenceLine y={avg} stroke="#D2C0A1" strokeDasharray="4 4" />
                  <Line type="monotone" dataKey="v" stroke="#A7BACC" strokeWidth={2.5} dot={{ r: 2.5, fill: '#A7BACC' }} activeDot={{ r: 5 }} animationDuration={800} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </SourceLock>

      <div className="mt-4">
        <HonestyNote>Baselines settle after 2–4 weeks of data.</HonestyNote>
      </div>
    </section>
  );
}
