import React from 'react';
import { Cpu, HeartPulse, Smartphone, CalendarDays, Database } from 'lucide-react';
import { useEngine } from '../../engine/EngineContext';
import { SOURCES } from '../../engine/dataset';
import { InfoTip } from './shared';

const SOURCE_ICONS = { health: HeartPulse, screen: Smartphone, calendar: CalendarDays };
const WINDOWS = [7, 14, 28];

function Switch({ on }) {
  return (
    <span className={`relative inline-flex w-8 h-[18px] rounded-full transition-colors duration-300 ${on ? 'bg-emerald-500/70' : 'bg-slate-700'}`}>
      <span className={`absolute top-[2px] w-[14px] h-[14px] rounded-full bg-white shadow transition-all duration-300 ${on ? 'left-[16px]' : 'left-[2px]'}`} />
    </span>
  );
}

/**
 * Control strip under the header: which sources the engine may use, and how
 * many days of history it looks at. Every change re-runs the engine live.
 */
export default function EngineBar() {
  const { sources, toggleSource, windowDays, setWindowDays, result, pulse } = useEngine();
  const found = result.tests.filter((t) => t.confidence === 'strong' || t.confidence === 'moderate').length;
  const locked = result.tests.filter((t) => t.locked).length;
  const idx = WINDOWS.indexOf(windowDays);

  return (
    <div key={pulse} className="engine-sweep rounded-2xl glass-panel px-4 py-3 mb-6 flex flex-col xl:flex-row xl:items-center gap-3 xl:gap-5">
      {/* Engine status */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-9 h-9 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center glow-pulse">
          <Cpu className="w-[18px] h-[18px] text-purple-300" />
        </div>
        <div>
          <div className="flex items-center gap-1.5 text-xs font-semibold text-white">
            Live insight engine
            <InfoTip text="Every number on these screens is calculated in your browser from the sample data: baselines, correlations (r), permutation tests (p) and day counts. Nothing is typed in by hand." />
          </div>
          <div className="text-[11px] font-mono text-slate-400">
            8 tests · <span className="text-emerald-300">{found} links</span> · <span className="text-rose-300">{locked} locked</span> · {result.ms.toFixed(0)} ms
          </div>
        </div>
      </div>

      <div className="hidden xl:block w-px h-9 bg-surface-border" />

      {/* Sources */}
      <div className="flex flex-wrap items-center gap-2 flex-1">
        <span className="text-[10px] uppercase tracking-wider font-semibold text-slate-500 mr-1">Sources</span>
        {Object.entries(SOURCES).map(([key, s]) => {
          const Icon = SOURCE_ICONS[key];
          const on = sources[key];
          return (
            <button
              key={key}
              onClick={() => toggleSource(key)}
              title={s.detail}
              className={`flex items-center gap-2 pl-2.5 pr-2 py-1.5 rounded-xl border text-xs font-medium transition-all duration-300 active:scale-95 ${
                on
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-100 hover:bg-emerald-500/15'
                  : 'bg-surface-card border-surface-border text-slate-500 hover:text-slate-300'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span className="hidden 2xl:inline">{s.label}</span>
              <span className="2xl:hidden">{s.short}</span>
              <Switch on={on} />
            </button>
          );
        })}
      </div>

      <div className="hidden xl:block w-px h-9 bg-surface-border" />

      {/* History window */}
      <div className="flex items-center gap-2 shrink-0">
        <span className="text-[10px] uppercase tracking-wider font-semibold text-slate-500 flex items-center gap-1">
          <Database className="w-3 h-3" /> History
        </span>
        <div className="relative flex p-1 rounded-xl bg-surface-card border border-surface-border">
          <span
            className="absolute top-1 bottom-1 rounded-lg bg-slate-700/70 border border-slate-500/40 transition-all duration-500 ease-out"
            style={{ left: `calc(${idx} * (100% - 8px) / 3 + 4px)`, width: 'calc((100% - 8px) / 3)' }}
          />
          {WINDOWS.map((w) => (
            <button
              key={w}
              onClick={() => setWindowDays(w)}
              className={`relative z-10 w-16 py-1 text-xs font-semibold font-mono transition-colors ${windowDays === w ? 'text-white' : 'text-slate-400 hover:text-slate-200'}`}
            >
              {w} days
            </button>
          ))}
        </div>
        <span className="hidden 2xl:inline px-2 py-1 rounded-md bg-slate-900 border border-slate-700/60 text-[10px] font-mono text-slate-400">
          SIMULATED DATA
        </span>
      </div>
    </div>
  );
}
