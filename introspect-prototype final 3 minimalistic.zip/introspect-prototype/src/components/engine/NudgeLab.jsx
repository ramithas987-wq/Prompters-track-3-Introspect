import React, { useEffect, useRef, useState } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceArea, ReferenceLine, Cell } from 'recharts';
import { Beaker, Play, RotateCcw, CheckCircle2, Circle, Sparkles, ArrowRight, Moon, Dumbbell, BellOff } from 'lucide-react';
import { useEngine } from '../../engine/EngineContext';
import { METRICS } from '../../engine/dataset';
import { NUDGES, simulateNudgeWeek, CONFIDENCE } from '../../engine/engine';
import { SectionTitle, SourceLock, HonestyNote, Pill, ConfidenceBadge } from './shared';

const ICONS = { phone_down: Moon, early_workout: Dumbbell, notif_off: BellOff };

export default function NudgeLab() {
  const { result, dataset, notify } = useEngine();
  const [selected, setSelected] = useState(NUDGES[0].id);
  const [run, setRun] = useState(null); // { sim, shown }
  const [runCount, setRunCount] = useState(0);
  const timer = useRef(null);

  const nudge = NUDGES.find((n) => n.id === selected);
  const basis = result.testsById[nudge.basedOn];
  const m = METRICS[nudge.target];

  useEffect(() => () => clearInterval(timer.current), []);
  useEffect(() => { clearInterval(timer.current); setRun(null); }, [selected, result.windowDays]);

  const start = () => {
    clearInterval(timer.current);
    const id = runCount + 1;
    setRunCount(id);
    const sim = simulateNudgeWeek(nudge, dataset, result.windowDays, id);
    setRun({ sim, shown: 0 });
    let shown = 0;
    timer.current = setInterval(() => {
      shown += 1;
      setRun((r) => (r ? { ...r, shown } : r));
      if (shown >= 7) {
        clearInterval(timer.current);
        notify(`Week simulated: ${sim.verdict.label.toLowerCase()}`, sim.verdict.key === 'promising' ? 'emerald' : 'purple');
      }
    }, 380);
  };

  const done = run && run.shown >= 7;
  const chartData = run ? run.sim.days.map((d, i) => ({ label: d.label, v: i < run.shown ? Number(d.value.toFixed(2)) : null, followed: d.followed })) : [];

  return (
    <section className="mb-12">
      <SectionTitle
        icon={Beaker}
        kicker="Act, then check"
        tone="pink"
        title="Nudge Lab"
        subtitle="Try one change, then check if it helped."
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Nudge picker */}
        <div className="lg:col-span-4 space-y-3 stagger">
          {NUDGES.map((n) => {
            const Icon = ICONS[n.id];
            const b = result.testsById[n.basedOn];
            const active = n.id === selected;
            return (
              <button
                key={n.id}
                onClick={() => setSelected(n.id)}
                className={`w-full text-left rounded-2xl border p-4 transition-all duration-300 ${
                  active ? 'bg-surface-subtle border-slate-400/60 translate-x-1' : 'bg-surface-card border-surface-border hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className={`w-8 h-8 rounded-lg flex items-center justify-center border ${active ? 'bg-pink-500/20 border-pink-400/40 text-pink-200' : 'bg-surface-subtle border-surface-border text-slate-400'}`}>
                    <Icon className="w-4 h-4" />
                  </span>
                  {b && <ConfidenceBadge confidence={b.confidence} />}
                </div>
                <div className="text-sm font-semibold text-white">{n.title}</div>
              </button>
            );
          })}
        </div>

        {/* Experiment panel */}
        <div className="lg:col-span-8">
          <SourceLock requires={nudge.requires}>
            <div key={selected} className="tab-enter rounded-2xl bg-surface-card border border-surface-border p-5 sm:p-6">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-5">
                <div>
                  <h3 className="text-xl font-semibold text-white">{nudge.title}</h3>
                  <p className="mt-2 text-xs text-slate-500">
                    Based on {basis.title.toLowerCase()}{basis.locked ? '' : ` (r ${basis.r.toFixed(2)})`} · checks {m.label.toLowerCase()} for 7 days
                  </p>
                </div>
                <div className="flex sm:flex-col gap-2 shrink-0">
                  <button
                    onClick={start}
                    disabled={run && !done}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-200 hover:bg-white disabled:opacity-50 text-[#121110] text-xs font-semibold shadow-glow transition-all active:scale-95"
                  >
                    <Play className="w-3.5 h-3.5" />
                    {run ? 'Simulate again' : 'Simulate next week'}
                  </button>
                  {run && (
                    <button onClick={() => { clearInterval(timer.current); setRun(null); }} className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-surface-subtle border border-surface-border text-slate-300 hover:text-white text-xs transition-colors">
                      <RotateCcw className="w-3.5 h-3.5" /> Reset
                    </button>
                  )}
                </div>
              </div>

              {!run && (
                <div className="rounded-xl border border-dashed border-surface-borderLight bg-[#161513] p-8 text-center">
                  <Sparkles className="w-6 h-6 text-pink-300 mx-auto mb-2" />
                  <p className="text-sm text-slate-400">Simulate the next 7 days with this nudge.</p>
                </div>
              )}

              {run && (
                <div className="rise-in">
                  {/* Day ticker */}
                  <div className="grid grid-cols-7 gap-1.5 mb-4">
                    {run.sim.days.map((d, i) => {
                      const shown = i < run.shown;
                      const better = (d.value - run.sim.bMean) * (m.better === 'up' ? 1 : -1) > 0;
                      return (
                        <div
                          key={d.label}
                          className={`rounded-lg border px-1 py-2 text-center transition-all duration-500 ${
                            shown ? (better ? 'bg-emerald-500/10 border-emerald-500/35' : 'bg-rose-500/10 border-rose-500/30') : 'bg-[#161513] border-surface-border opacity-40'
                          }`}
                        >
                          <div className="text-[10px] font-mono text-slate-400">{d.label}</div>
                          <div className="text-[11px] font-bold text-white mt-0.5">{shown ? m.fmt(d.value) : '…'}</div>
                          <div className="flex justify-center mt-1">
                            {shown ? (d.followed ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <Circle className="w-3 h-3 text-slate-500" />) : <span className="w-3 h-3" />}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  <div className="text-[10px] text-slate-500 flex items-center gap-3 mb-3">
                    <span className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3 text-emerald-400" /> nudge followed</span>
                    <span className="flex items-center gap-1"><Circle className="w-3 h-3 text-slate-500" /> forgot</span>
                    <span className="ml-auto font-mono">SIMULATED WEEK</span>
                  </div>

                  <div className="h-52 rounded-xl bg-[#161513] border border-surface-border p-2 mb-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData} margin={{ top: 10, right: 10, left: -14, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#2A2825" vertical={false} />
                        <XAxis dataKey="label" stroke="#7F7973" tick={{ fontSize: 10 }} />
                        <YAxis stroke="#7F7973" tick={{ fontSize: 10 }} domain={['auto', 'auto']} />
                        <Tooltip cursor={{ fill: 'rgba(168, 162, 158,0.06)' }} contentStyle={{ background: '#1C1B18', border: '1px solid #2E2C28', borderRadius: 10, fontSize: 11 }} formatter={(v) => [v == null ? '…' : m.fmt(v), m.label]} />
                        <ReferenceArea y1={run.sim.bMean - run.sim.bSd} y2={run.sim.bMean + run.sim.bSd} fill="#BFA883" fillOpacity={0.1} stroke="none" />
                        <ReferenceLine y={run.sim.bMean} stroke="#D2C0A1" strokeDasharray="4 4" label={{ value: 'your normal', fill: '#D2C0A1', fontSize: 10, position: 'insideTopLeft' }} />
                        <Bar dataKey="v" radius={[5, 5, 0, 0]} barSize={26} isAnimationActive={false}>
                          {chartData.map((d) => (
                            <Cell key={d.label} fill={d.v != null && (d.v - run.sim.bMean) * (m.better === 'up' ? 1 : -1) > 0 ? '#86A87E' : '#DA978A'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  <div className={`expand ${done ? 'open' : ''}`}>
                    <div>
                      <div className={`rounded-xl border p-4 flex flex-col sm:flex-row sm:items-center gap-4 ${
                        run.sim.verdict.key === 'promising' ? 'bg-emerald-500/10 border-emerald-500/35' : run.sim.verdict.key === 'early' ? 'bg-amber-500/10 border-amber-500/35' : 'bg-slate-500/10 border-slate-500/35'
                      }`}>
                        <div className="shrink-0 text-center sm:pr-4 sm:border-r border-white/10">
                          <div className="text-[10px] uppercase tracking-wider text-slate-400">Change vs normal</div>
                          <div className="text-2xl font-bold font-mono text-white">{run.sim.deltaText}</div>
                          <div className="text-[10px] font-mono text-slate-400">{run.sim.zShift >= 0 ? '+' : '−'}{Math.abs(run.sim.zShift).toFixed(1)} SD</div>
                        </div>
                        <div className="flex-1">
                          <div className="text-sm font-bold text-white flex items-center gap-2">
                            {run.sim.verdict.label}
                            <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                          </div>
                          <p className="text-xs text-slate-400 mt-1">
                            Better than normal on {run.sim.daysBetter} of 7 days.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </SourceLock>
          <div className="mt-4">
            <HonestyNote>Simulated week. The real app checks your actual next 7 days.</HonestyNote>
          </div>
        </div>
      </div>
    </section>
  );
}
