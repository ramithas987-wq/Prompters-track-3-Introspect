import React, { useState } from 'react';
import { 
  Moon, 
  Footprints, 
  Flame, 
  HeartPulse, 
  Smartphone, 
  AppWindow, 
  HandMetal, 
  BellRing, 
  ShieldAlert,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  Clock,
  Sparkles,
  Info
} from 'lucide-react';
import { HEALTH_METRICS, DIGITAL_METRICS, APP_USAGE_BREAKDOWN } from '../data/mockData';
import { SourceLock } from './engine/shared';

export default function Dashboard({ onSelectInsight }) {
  const [selectedMetric, setSelectedMetric] = useState(null);

  const getMetricIcon = (iconName, color) => {
    const props = { className: "w-5 h-5", style: { color } };
    switch (iconName) {
      case 'Moon': return <Moon {...props} />;
      case 'Footprints': return <Footprints {...props} />;
      case 'Flame': return <Flame {...props} />;
      case 'HeartPulse': return <HeartPulse {...props} />;
      case 'Smartphone': return <Smartphone {...props} />;
      case 'AppWindow': return <AppWindow {...props} />;
      case 'HandMetal': return <HandMetal {...props} />;
      case 'BellRing': return <BellRing {...props} />;
      case 'ShieldAlert': return <ShieldAlert {...props} />;
      default: return <Clock {...props} />;
    }
  };

  return (
    <div className="space-y-8 mb-12">
      
      {/* SECTION 1: Health & Activity */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div className="flex items-center space-x-2">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
            <h2 className="text-xl font-bold text-white tracking-tight">
              Health & Activity
            </h2>
          </div>
        </div>

        <SourceLock requires={['health']} compact>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 stagger">
          {HEALTH_METRICS.map((metric) => (
            <div
              key={metric.id}
              onClick={() => setSelectedMetric(selectedMetric === metric.id ? null : metric.id)}
              className={`cursor-pointer rounded-xl bg-surface-card hover:bg-surface-hover border transition-all duration-200 p-4 relative group flex flex-col justify-between hover:-translate-y-0.5 ${
                selectedMetric === metric.id 
                  ? 'border-cyan-500/60 shadow-cyanGlow' 
                  : 'border-surface-border hover:border-slate-600'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div 
                    className="w-10 h-10 rounded-lg flex items-center justify-center border border-white/5"
                    style={{ backgroundColor: `${metric.color}15` }}
                  >
                    {getMetricIcon(metric.icon, metric.color)}
                  </div>
                </div>

                <div className="text-xs font-medium text-slate-400">
                  {metric.label}
                </div>

                <div className="text-2xl font-bold text-white font-mono mt-1 tracking-tight">
                  {metric.value}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-surface-border/60">
                <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
                  <span className={`font-medium ${
                    metric.status === 'warning' ? 'text-amber-400' : 'text-emerald-400'
                  }`}>
                    {metric.delta}
                  </span>
                </div>
              </div>

              {/* Interactive micro badge */}
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <Info className="w-3.5 h-3.5 text-slate-500 hover:text-cyan-400" />
              </div>
            </div>
          ))}
        </div>
        </SourceLock>
      </div>

      {/* SECTION 2: Digital Behaviour */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div className="flex items-center space-x-2">
            <div className="w-2.5 h-2.5 rounded-full bg-purple-400" />
            <h2 className="text-xl font-bold text-white tracking-tight">
              Digital Behaviour
            </h2>
          </div>
        </div>

        <SourceLock requires={['screen']} compact>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 stagger">
          {DIGITAL_METRICS.map((metric) => (
            <div
              key={metric.id}
              onClick={() => setSelectedMetric(selectedMetric === metric.id ? null : metric.id)}
              className={`cursor-pointer rounded-xl bg-surface-card hover:bg-surface-hover border transition-all duration-200 p-4 relative group flex flex-col justify-between hover:-translate-y-0.5 ${
                selectedMetric === metric.id 
                  ? 'border-purple-500/60 shadow-glow' 
                  : 'border-surface-border hover:border-slate-600'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div 
                    className="w-10 h-10 rounded-lg flex items-center justify-center border border-white/5"
                    style={{ backgroundColor: `${metric.color}15` }}
                  >
                    {getMetricIcon(metric.icon, metric.color)}
                  </div>
                </div>

                <div className="text-xs font-medium text-slate-400">
                  {metric.label}
                </div>

                <div className="text-2xl font-bold text-white font-mono mt-1 tracking-tight">
                  {metric.value}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-surface-border/60">
                <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
                  <span className={`font-medium shrink-0 ${
                    metric.status === 'alert' 
                      ? 'text-rose-400' 
                      : metric.status === 'warning' 
                      ? 'text-amber-400' 
                      : 'text-slate-300'
                  }`}>
                    {metric.delta}
                  </span>
                </div>
              </div>

              {/* Interactive micro badge */}
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <Info className="w-3.5 h-3.5 text-slate-500 hover:text-purple-400" />
              </div>
            </div>
          ))}
        </div>

        {/* Breakdown bar: Most used app contextual breakdown */}
        <div className="mt-4 p-4 rounded-xl bg-[#161513] border border-surface-border flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-pink-500/10 border border-pink-500/20 flex items-center justify-center text-pink-400">
              <AppWindow className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-semibold text-white">
                App Attention Distribution
              </div>
              <div className="text-[11px] text-slate-400">
                Instagram leads total screen engagement (2h 14m), followed by YouTube and WhatsApp
              </div>
            </div>
          </div>

          <div className="flex-1 max-w-md">
            <div className="h-2.5 w-full bg-slate-800 rounded-full overflow-hidden flex">
              {APP_USAGE_BREAKDOWN.map((app) => (
                <div
                  key={app.name}
                  style={{ width: `${app.percent}%`, backgroundColor: app.color }}
                  title={`${app.name}: ${app.minutes}m (${app.percent}%)`}
                  className="h-full transition-all hover:opacity-80 cursor-pointer"
                />
              ))}
            </div>
            <div className="flex items-center justify-between mt-1 text-[10px] text-slate-400">
              {APP_USAGE_BREAKDOWN.map((app) => (
                <span key={app.name} className="flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: app.color }} />
                  <span>{app.name} ({app.percent}%)</span>
                </span>
              ))}
            </div>
          </div>
        </div>
        </SourceLock>

      </div>

    </div>
  );
}
