import React from 'react';
import { 
  TrendingUp, 
  AlertTriangle, 
  Moon, 
  CheckCircle2, 
  Clock, 
  Calendar,
  Sparkles,
  ArrowUpRight
} from 'lucide-react';
import { DAILY_SUMMARY_TEXT } from '../data/mockData';

export default function DailySummary({ onJumpToInsights }) {
  const { title, overview, highlights, score, scoreLabel } = DAILY_SUMMARY_TEXT;

  return (
    <div className="relative rounded-2xl bg-surface-card border border-surface-border p-5 sm:p-6 mb-8 shadow-card overflow-hidden">
      
      {/* Decorative accent lines */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        
        {/* Left: Summary text & Daily insight */}
        <div className="flex-1">
          <div className="flex items-center space-x-2.5 mb-2">
            <span className="inline-flex items-center justify-center w-6 h-6 rounded-md bg-purple-500/20 text-purple-400">
              <Sparkles className="w-3.5 h-3.5" />
            </span>
            <h2 className="text-lg font-bold text-white tracking-wide">
              {title}
            </h2>
            <span className="text-[11px] font-mono text-slate-400 bg-surface-subtle px-2 py-0.5 rounded border border-surface-border">
              Today • 24 Nov
            </span>
          </div>

          <p className="text-sm sm:text-base text-slate-200 font-medium leading-relaxed bg-[#141311]/60 p-3.5 rounded-xl border border-surface-border/60">
            "{overview}"
          </p>

          {/* Quick takeaway bullets */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
            {highlights.map((h, i) => (
              <div 
                key={i}
                className="flex items-center space-x-2.5 bg-surface-subtle/70 px-3 py-2 rounded-lg border border-surface-border/50 text-xs"
              >
                {h.color === 'emerald' && <TrendingUp className="w-4 h-4 text-emerald-400 shrink-0" />}
                {h.color === 'amber' && <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />}
                {h.color === 'purple' && <Moon className="w-4 h-4 text-purple-400 shrink-0" />}
                <div className="truncate">
                  <span className="text-slate-400 block text-[11px]">{h.label}</span>
                  <span className="text-slate-200 font-medium truncate block">{h.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Synthesis Score / Harmony Index */}
        <div className="flex sm:flex-row lg:flex-col items-center justify-between lg:justify-center p-4 bg-[#161513] rounded-xl border border-purple-500/20 min-w-[210px] shrink-0 text-center">
          <div className="text-left sm:text-center lg:text-center">
            <div className="text-[11px] font-mono uppercase tracking-wider text-purple-300 font-semibold mb-1">
              {scoreLabel}
            </div>
            <div className="flex items-baseline justify-start sm:justify-center space-x-1">
              <span className="text-4xl font-extrabold text-white font-serif">
                {score}
              </span>
              <span className="text-xs text-slate-500 font-mono">/ 100</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Balanced activity vs Screen friction
            </div>
          </div>

          <button
            onClick={onJumpToInsights}
            className="mt-0 sm:mt-0 lg:mt-3 px-3 py-1.5 rounded-lg bg-surface-subtle hover:bg-surface-hover border border-surface-border hover:border-purple-500/40 text-xs text-purple-300 font-medium transition-all flex items-center space-x-1"
          >
            <span>View Correlations</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
}
