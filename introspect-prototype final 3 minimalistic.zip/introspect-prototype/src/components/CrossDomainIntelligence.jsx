import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  ComposedChart, 
  LineChart, 
  BarChart, 
  Bar, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  CartesianGrid, 
  Area 
} from 'recharts';
import { 
  Network, 
  Layers, 
  HelpCircle, 
  Smartphone, 
  Moon, 
  Flame, 
  Footprints, 
  ArrowRight,
  TrendingDown,
  TrendingUp,
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { useEngine } from '../engine/EngineContext';
import { CONFIDENCE } from '../engine/engine';
import { SourceLock } from './engine/shared';

const r2 = (v) => Math.round(v * 100) / 100;
const conf = (t) => CONFIDENCE[t.confidence].label.toLowerCase();
const rText = (t) => (t.locked ? 'locked' : `r = ${t.r >= 0 ? '+' : '−'}${Math.abs(t.r).toFixed(2)}`);

// Custom dark theme tooltip for Recharts
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#1C1B18] border border-surface-border p-3 rounded-xl shadow-card text-xs">
        <p className="font-semibold text-slate-200 mb-1.5 font-mono">{label}</p>
        {payload.map((entry, index) => (
          <div key={`item-${index}`} className="flex items-center justify-between space-x-3 py-0.5">
            <span className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="text-slate-400">{entry.name}:</span>
            </span>
            <span className="font-mono font-bold text-white">
              {entry.value} {entry.unit || ''}
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export default function CrossDomainIntelligence() {
  const [activeGraph, setActiveGraph] = useState('all');
  const { result, dataset } = useEngine();
  const T = result.testsById;

  // Charts always show the last 7 days; the statistics use the whole history window.
  const recent = dataset.slice(-8);
  const SCREEN_VS_SLEEP_DATA = recent.slice(1).map((d) => ({
    day: d.isToday ? 'Today' : d.label, screenTime: r2(d.screenHrs), lateNightScreen: r2(d.lateNightMins / 60), sleepDuration: r2(d.sleepHrs),
  }));
  const EXERCISE_VS_SLEEP_DATA = recent.slice(1).map((d) => ({
    day: d.isToday ? 'Today' : d.label, exerciseMins: Math.round(d.exerciseMins), deepSleepMins: Math.round(d.deepSleepMins),
  }));
  const LATE_PHONE_VS_STEPS_DATA = recent.slice(1).map((d, i) => ({
    day: d.isToday ? 'Today' : d.label, lateNightUsageMins: Math.round(recent[i].lateNightMins), nextDaySteps: Math.round(d.steps),
  }));
  const stepsPerHour = Math.round(Math.abs(T.late_nextsteps.perUnit || 0) * 60);

  return (
    <section className="mb-12" id="cross-domain-section">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Cross-Domain
          </h2>
          <p className="text-sm text-slate-500 mt-1">Your habits side by side. Last 7 days shown.</p>
        </div>

        {/* Graph selector buttons */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-surface-card rounded-xl border border-surface-border">
          {[
            { id: 'all', label: 'All' },
            { id: 'screen-sleep', label: 'Screen · Sleep' },
            { id: 'exercise-sleep', label: 'Exercise · Sleep' },
            { id: 'late-steps', label: 'Late phone · Steps' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveGraph(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeGraph === tab.id
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-surface-subtle'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-8">
        
        {/* GRAPH 1: Screen Time vs Sleep Duration */}
        {(activeGraph === 'all' || activeGraph === 'screen-sleep') && (
          <SourceLock requires={['screen', 'health']}>
          <div className="rise-in rounded-2xl bg-surface-card border border-surface-border p-5 sm:p-6 shadow-card">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-6 pb-4 border-b border-surface-border/60">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-400" />
                  <h3 className="text-lg font-bold text-white">
                    Screen time and sleep
                  </h3>
                </div>
              </div>
              <div className="flex items-center space-x-2 text-xs font-mono bg-purple-500/10 border border-purple-500/20 text-purple-300 px-3 py-1 rounded-lg">
                <TrendingDown className="w-3.5 h-3.5 text-purple-400" />
                <span>Late-night {rText(T.late_sleep)} · Total {rText(T.screen_sleep)}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              {/* Chart container */}
              <div className="lg:col-span-8 h-72 sm:h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={SCREEN_VS_SLEEP_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2A2825" vertical={false} />
                    <XAxis dataKey="day" stroke="#7F7973" tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="left" stroke="#8AA2BA" domain={[0, 10]} tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="right" orientation="right" stroke="#BFA883" domain={[0, 10]} tick={{ fontSize: 11 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend 
                      verticalAlign="top" 
                      height={36}
                      formatter={(value) => <span className="text-xs text-slate-300">{value}</span>}
                    />
                    <Bar 
                      yAxisId="left" 
                      dataKey="screenTime" 
                      name="Screen Time (hrs)" 
                      fill="#6F89A3" 
                      radius={[4, 4, 0, 0]} 
                      barSize={20}
                    />
                    <Bar 
                      yAxisId="left" 
                      dataKey="lateNightScreen" 
                      name="After 11 PM (hrs)" 
                      fill="#CB7767" 
                      radius={[4, 4, 0, 0]} 
                      barSize={20}
                    />
                    <Line 
                      yAxisId="right" 
                      type="monotone" 
                      dataKey="sleepDuration" 
                      name="Sleep Duration (hrs)" 
                      stroke="#BFA883" 
                      strokeWidth={3} 
                      dot={{ r: 4, fill: '#BFA883' }}
                      activeDot={{ r: 6 }}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>

              {/* Side explanation */}
              <div className="lg:col-span-4 bg-[#161513] p-4 sm:p-5 rounded-xl border border-surface-border space-y-3">
                <div className="flex items-center space-x-2 text-xs font-semibold text-purple-300 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>What it shows</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  <strong className="text-white">It's when, not how much.</strong>{' '}
                  Late-night use: {conf(T.late_sleep)}. Total screen time: {conf(T.screen_sleep)}.
                </p>
              </div>
            </div>
          </div>
          </SourceLock>
        )}

        {/* GRAPH 2: Exercise vs Sleep Quality / Duration */}
        {(activeGraph === 'all' || activeGraph === 'exercise-sleep') && (
          <SourceLock requires={['health']}>
          <div className="rise-in rounded-2xl bg-surface-card border border-surface-border p-5 sm:p-6 shadow-card">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-6 pb-4 border-b border-surface-border/60">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  <h3 className="text-lg font-bold text-white">
                    Exercise and deep sleep
                  </h3>
                </div>
              </div>
              <div className="flex items-center space-x-2 text-xs font-mono bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 px-3 py-1 rounded-lg">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                <span>{T.exercise_deep.locked ? 'Locked' : `${T.exercise_deep.effectText} deep sleep on workout days · ${rText(T.exercise_deep)}`}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              {/* Chart container */}
              <div className="lg:col-span-8 h-72 sm:h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={EXERCISE_VS_SLEEP_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2A2825" vertical={false} />
                    <XAxis dataKey="day" stroke="#7F7973" tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="left" stroke="#6C8F64" domain={[0, 70]} tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="right" orientation="right" stroke="#A7BACC" domain={[0, 130]} tick={{ fontSize: 11 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend 
                      verticalAlign="top" 
                      height={36}
                      formatter={(value) => <span className="text-xs text-slate-300">{value}</span>}
                    />
                    <Bar 
                      yAxisId="left" 
                      dataKey="exerciseMins" 
                      name="Exercise (mins)" 
                      fill="#6C8F64" 
                      radius={[4, 4, 0, 0]} 
                      barSize={20}
                    />
                    <Bar 
                      yAxisId="right" 
                      dataKey="deepSleepMins" 
                      name="Deep Sleep (mins)" 
                      fill="#8AA2BA" 
                      radius={[4, 4, 0, 0]} 
                      barSize={20}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Side explanation */}
              <div className="lg:col-span-4 bg-[#161513] p-4 sm:p-5 rounded-xl border border-surface-border space-y-3">
                <div className="flex items-center space-x-2 text-xs font-semibold text-emerald-300 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span>What it shows</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {T.exercise_deep.sentence}
                </p>
              </div>
            </div>
          </div>
          </SourceLock>
        )}

        {/* GRAPH 3: Late-Night Phone Usage vs Next-Day Steps */}
        {(activeGraph === 'all' || activeGraph === 'late-steps') && (
          <SourceLock requires={['screen', 'health']}>
          <div className="rise-in rounded-2xl bg-surface-card border border-surface-border p-5 sm:p-6 shadow-card">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 mb-6 pb-4 border-b border-surface-border/60">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                  <h3 className="text-lg font-bold text-white">
                    Late-night phone use and next-day steps
                  </h3>
                </div>
              </div>
              <div className="flex items-center space-x-2 text-xs font-mono bg-rose-500/10 border border-rose-500/20 text-rose-300 px-3 py-1 rounded-lg">
                <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                <span>{T.late_nextsteps.locked ? 'Locked' : `~${stepsPerHour.toLocaleString('en-IN')} fewer steps per extra hour of late use · ${rText(T.late_nextsteps)}`}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              {/* Chart container */}
              <div className="lg:col-span-8 h-72 sm:h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={LATE_PHONE_VS_STEPS_DATA} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2A2825" vertical={false} />
                    <XAxis dataKey="day" stroke="#7F7973" tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="left" stroke="#CB7767" domain={[0, 120]} tick={{ fontSize: 11 }} />
                    <YAxis yAxisId="right" orientation="right" stroke="#BFA883" domain={[0, 11000]} tick={{ fontSize: 11 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend 
                      verticalAlign="top" 
                      height={36}
                      formatter={(value) => <span className="text-xs text-slate-300">{value}</span>}
                    />
                    <Bar 
                      yAxisId="left" 
                      dataKey="lateNightUsageMins" 
                      name="Late-Night Usage (mins)" 
                      fill="#CB7767" 
                      radius={[4, 4, 0, 0]} 
                      barSize={20}
                    />
                    <Line 
                      yAxisId="right" 
                      type="monotone" 
                      dataKey="nextDaySteps" 
                      name="Next-Day Steps" 
                      stroke="#BFA883" 
                      strokeWidth={3} 
                      dot={{ r: 4, fill: '#BFA883' }}
                      activeDot={{ r: 6 }}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>

              {/* Side explanation */}
              <div className="lg:col-span-4 bg-[#161513] p-4 sm:p-5 rounded-xl border border-surface-border space-y-3">
                <div className="flex items-center space-x-2 text-xs font-semibold text-rose-300 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-rose-400" />
                  <span>What it shows</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {T.late_nextsteps.sentence}
                </p>
              </div>
            </div>
          </div>
          </SourceLock>
        )}

      </div>

    </section>
  );
}
