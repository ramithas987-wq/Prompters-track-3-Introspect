import React from 'react';
import { 
  Layers, 
  Network, 
  Sparkles, 
  ArrowRight, 
  Smartphone, 
  HeartPulse, 
  Brain,
  HelpCircle
} from 'lucide-react';
import { CONCEPT_PILLARS } from '../data/mockData';

export default function ConceptHero({ onExploreInsights }) {
  const getIcon = (iconName) => {
    switch (iconName) {
      case 'Layers': return <Layers className="w-5 h-5 text-cyan-400" />;
      case 'Network': return <Network className="w-5 h-5 text-purple-400" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-pink-400" />;
      default: return <Brain className="w-5 h-5 text-purple-400" />;
    }
  };

  return (
    <section className="relative overflow-hidden rounded-2xl bg-surface-card border border-surface-border p-6 sm:p-8 mb-8">
      {/* Subtle background glow effects */}
      {/* Top Banner Tag */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5 text-purple-400" />
          <span>Ideathon Vision • Beyond Single-Metric Trackers</span>
        </div>
        <div className="text-xs text-slate-400 font-mono">
          Architecture: Sensor Synthesis Layer
        </div>
      </div>

      {/* Heading & Elevator Pitch */}
      <div className="max-w-3xl mb-8">
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-tight">
          Your phone tracks your screen. Your watch tracks your body.{' '}
          <span className="font-serif italic text-purple-300">
            Introspect connects them.
          </span>
        </h1>
        <p className="mt-3 text-sm sm:text-base text-slate-300 leading-relaxed">
          Introspect analyzes your existing smartphone sensor streams—screen time, notifications, 
          sleep, steps, and heart rate—in unison to reveal how digital habits secretly shape 
          physical recovery, energy, and mental focus.
        </p>
      </div>

      {/* 3 Step Concept Cards: Collect -> Understand -> Act */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {CONCEPT_PILLARS.map((pillar, idx) => (
          <div
            key={pillar.step}
            className="group relative rounded-xl bg-surface-card/80 hover:bg-surface-hover/80 border border-surface-border hover:border-purple-500/40 p-5 transition-all duration-300 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-lg bg-surface-subtle border border-surface-border flex items-center justify-center">
                    {getIcon(pillar.icon)}
                  </div>
                  <span className="text-xs font-mono font-bold tracking-widest text-slate-400">
                    STEP {pillar.step}
                  </span>
                </div>
                <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-surface-subtle border border-surface-border text-slate-200">
                  {pillar.tag}
                </span>
              </div>

              <h3 className="text-base font-semibold text-white mb-1.5 group-hover:text-purple-300 transition-colors">
                {pillar.title}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {pillar.description}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-surface-border/50 flex items-center justify-between text-[11px] text-slate-400">
              <span className="font-mono">
                {idx === 0 ? "Passive Hardware Signals" : idx === 1 ? "Multi-Variate Correlation" : "Micro-Habit Suggestions"}
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-purple-400 group-hover:translate-x-0.5 transition-all" />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
