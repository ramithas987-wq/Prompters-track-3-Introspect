import React from 'react';
import { 
  X, 
  Presentation, 
  Layers, 
  Sparkles, 
  CheckCircle2, 
  FileText, 
  Target,
  Zap,
  ShieldCheck,
  FolderGit2
} from 'lucide-react';

export default function PitchOverviewModal({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[#161513] border border-surface-border p-6 sm:p-8 shadow-2xl text-slate-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-surface-subtle text-slate-400 hover:text-white hover:bg-surface-hover transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Presentation className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">
              INTROSPECT — Ideathon Presentation Guide
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              3-Minute Pitch Framework • Prototype Walkthrough
            </p>
          </div>
        </div>

        {/* 1. Core Problem & Solution */}
        <div className="space-y-6">
          <div className="p-4 rounded-xl bg-surface-card border border-surface-border">
            <div className="flex items-center space-x-2 text-rose-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Target className="w-4 h-4" />
              <span>1. The Core Problem</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Modern smartphones and wearables collect massive amounts of data, but in 
              <strong className="text-white"> disconnected silos</strong>. Health apps don't know why your sleep was ruined, 
              and screen time apps don't show whether your late-night scrolling lines up with fewer steps the next day.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-surface-card border border-purple-500/30">
            <div className="flex items-center space-x-2 text-purple-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Zap className="w-4 h-4" />
              <span>2. The Solution: Personal Intelligence System</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              INTROSPECT analyzes existing on-device data streams together:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3 text-xs">
              <div className="bg-[#1A1917] p-3 rounded-lg border border-surface-border">
                <span className="font-bold text-cyan-400 block mb-1">1. Collect</span>
                Integrates sleep, steps, workouts, heart rate, screen time, app usage, and pickups.
              </div>
              <div className="bg-[#1A1917] p-3 rounded-lg border border-surface-border">
                <span className="font-bold text-purple-400 block mb-1">2. Understand</span>
                Discovers cross-domain correlations (e.g. late screen → sleep deficit → daytime step drop).
              </div>
              <div className="bg-[#1A1917] p-3 rounded-lg border border-surface-border">
                <span className="font-bold text-pink-400 block mb-1">3. Act</span>
                Delivers personalized micro-recommendations tailored to your natural daily routine.
              </div>
            </div>
          </div>

          {/* 3. Deliverables Checklist (Aligned with Ideathon submission criteria) */}
          <div className="p-4 rounded-xl bg-[#121110] border border-surface-border">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center space-x-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Ideathon Submission Checklist</span>
              </span>
              <span className="text-[11px] font-mono text-emerald-400">Prototype Ready</span>
            </div>

            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                <span><strong>Clean, Modern Dark UI:</strong> Charcoal background with purple & blue accents, responsive layout.</span>
              </li>
              <li className="flex items-start space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                <span><strong>Complete Dashboard:</strong> Health & Activity cards + Digital Behaviour cards matching exact demo values.</span>
              </li>
              <li className="flex items-start space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                <span><strong>Behavioural Insights:</strong> 4 cross-domain connections with explanations and actionable recommendations.</span>
              </li>
              <li className="flex items-start space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                <span><strong>Cross-Domain Intelligence:</strong> 3 interactive Recharts comparison charts with side-by-side explanations.</span>
              </li>
              <li className="flex items-start space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                <span><strong>Daily Summary:</strong> "Your Day at a Glance" synthesis and Harmony Index score.</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-surface-border flex items-center justify-between">
          <span className="text-xs text-slate-500 font-mono">
            INTROSPECT Prototype v0.1 • Fixed Sample Data
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-all"
          >
            Back to Prototype
          </button>
        </div>

      </div>
    </div>
  );
}
