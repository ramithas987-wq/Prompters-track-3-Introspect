# INTROSPECT — Personal Intelligence System

> **Ideathon Prototype (Track Submission)**  
> *Transforming fragmented smartphone & wearable signals into actionable lifestyle intelligence.*

---

## 📌 Executive Concept

Most health and digital wellbeing applications operate in **isolated data silos**:
* **Smartwatches & Fitness Trackers** record sleep duration, heart rate, and workouts, but cannot explain *why* sleep deteriorated or recovery stalled.
* **Screen Time & Digital Wellbeing Tools** count screen hours, app usage, and notifications, but have zero awareness of your physical state or circadian rhythm.

**INTROSPECT** bridges this gap. It combines the data your phone already collects and tests how your digital habits and physical health relate, comparing you with your own normal and showing how strong the evidence is (association, not proof).

```
┌─────────────────────────────────┐
│           1. COLLECT            │
│  Sleep • Steps • Workouts • HR  │
│  Screen Time • Pickups • Apps   │
└────────────────┬────────────────┘
                 │
                 ▼
┌─────────────────────────────────┐
│          2. UNDERSTAND          │
│ Personal baselines + link tests │
│ r, p and "X of Y days" evidence │
└────────────────┬────────────────┘
                 │
                 ▼
┌─────────────────────────────────┐
│             3. ACT              │
│ Contextual micro-interventions  │
│ Personalized habit adjustments  │
└─────────────────────────────────┘
```

---

## 🚀 Key Features in this Prototype

### 1. Unified Dashboard
* **Health & Activity**:
  * 💤 **Sleep Duration**: 6h 45m (Deep sleep: 1h 20m, REM: 1h 45m)
  * 👟 **Steps**: 8,432 (+18% vs last week)
  * 🏃 **Exercise**: 4 workouts this week (Weekly target achieved)
  * ❤️ **Resting Heart Rate**: 64 BPM (Normal baseline)
* **Digital Behaviour**:
  * 📱 **Screen Time**: 6h 32m (Peak between 8 PM - 11 PM)
  * 📸 **Most Used App**: Instagram (2h 14m)
  * 🖐️ **Phone Pickups**: 72 pickups / day
  * 🔔 **Notifications**: 146 notifications
  * 🌙 **Late-Night Usage**: 1h 15m (after 11:00 PM)

### 2. Live Insight Engine (new, runs in the browser)
* **Simulated 28-day dataset** (`src/engine/dataset.js`), labelled as sample data on every screen.
* **8 link tests** (`src/engine/engine.js`): Pearson r, a 2,000-shuffle permutation test (p), and "X of Y days" counts. Results are labelled *Strong link*, *Moderate link*, *No clear link* or *Not enough data yet* (fewer than 14 days).
* **Source switches**: turning off Health Connect, Screen Time or Google Calendar locks every insight that needs it.
* **History window**: 7 / 14 / 28 days. At 7 days the engine refuses to call anything a link.

### 3. New screens
* **Insights → Link Tests**: all 8 tests with evidence, expandable scatter plots.
* **Your Normal**: 28-day calendar coloured against your personal baseline, today vs your normal vs a generic target.
* **Nudge Lab**: pick a suggestion, simulate the next week, and see how Introspect checks whether it helped.
* **Weekly Report**: one-page summary built from the engine's results.

### 4. Cross-Domain Intelligence (Interactive Graphs)
* **Comparison 1**: Total and late-night screen time vs. sleep (shows that *when* matters more than *how much* in the sample data).
* **Comparison 2**: Exercise minutes vs. deep sleep.
* **Comparison 3**: Late-night usage vs. next-day steps.

All chart values and statistics now come from the live engine.

### 5. "Your Day at a Glance" Daily Synthesis
An executive daily summary providing a high-level takeaway of your lifestyle harmony index score and immediate actionable micro-steps.

---

## 🛠️ Tech Stack

* **Framework**: React 18 + Vite
* **Styling**: Tailwind CSS (Custom Charcoal & Obsidian Dark Theme with Purple/Cyan Accents)
* **Visualizations**: Recharts
* **Icons**: Lucide React
* **Data State**: Deterministic simulated dataset + in-browser insight engine (no backend needed for the ideathon demo). Planned for the hackathon: Python/FastAPI engine, Supabase, Android collectors.

---

## 🏃 How to Run Locally

### Prerequisites
* Node.js (v18 or higher recommended)
* npm or pnpm

### Setup Instructions
```bash
# 1. Clone or navigate to the directory
cd introspect-prototype

# 2. Install dependencies
npm install

# 3. Start local development server
npm run dev

# 4. Or build and preview production bundle
npm run build
npm run preview
```

Open `http://localhost:3000` (or the URL shown in your terminal) in your browser.

---

## 🎯 Ideathon Video & Pitch Structure (3–5 min Guide)

1. **Problem (0:00 - 1:00)**: Show how users switch between Apple Health and Screen Time without actionable answers.
2. **Solution (1:00 - 2:00)**: Walk through the INTROSPECT Dashboard and explain the *Collect · Understand · Act* framework.
3. **Demo (2:00 - 3:30)**: Show the live Link Tests, switch a source off, change the history window, and run a Nudge Lab week.
4. **Impact & Future (3:30 - 4:00)**: On-device private AI models synthesizing health habits without uploading personal telemetry to external servers.

---

*Clearly labeled as DEMO DATA for Ideathon Presentation.*

## Design (updated)
* Calm, warm-neutral dark theme: charcoal surfaces, one ink-blue accent and a sand secondary.
* Muted status colours: sage = better, ochre = moderate, brick = worse.
* IBM Plex Sans / Plex Mono for text and numbers, Fraunces serif for headings.
* No glows, neon gradients or blurred colour blobs; smaller corner radii.
* Colours live in `tailwind.config.js` — the old purple/cyan/pink names are remapped there, so changing the palette is a one-file edit.
