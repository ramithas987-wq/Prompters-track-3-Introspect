/** @type {import('tailwindcss').Config} */

// Calm, warm-neutral palette. One accent (ink blue) + one secondary (sand).
// Status colours are muted: sage = better, ochre = moderate, brick = worse.
const ink = { 50: '#F2F5F8', 100: '#E1E8EF', 200: '#C5D2DF', 300: '#A7BACC', 400: '#8AA2BA', 500: '#6F89A3', 600: '#5A7189', 700: '#485B6F', 800: '#374655', 900: '#27323D', 950: '#1A2129' };
const sand = { 50: '#FAF7F2', 100: '#F1EADF', 200: '#E3D6C1', 300: '#D2C0A1', 400: '#BFA883', 500: '#A88F6A', 600: '#8C7655', 700: '#6F5D43', 800: '#534532', 900: '#3A3023', 950: '#241E16' };
const sage = { 50: '#F2F6F1', 100: '#E0EADD', 200: '#C3D6BE', 300: '#A3BF9C', 400: '#86A87E', 500: '#6C8F64', 600: '#57754F', 700: '#455C3F', 800: '#344530', 900: '#253022', 950: '#171E15' };
const ochre = { 50: '#FBF6EC', 100: '#F5E9CF', 200: '#EBD39E', 300: '#DFBC72', 400: '#D2A650', 500: '#B98C3A', 600: '#97712E', 700: '#765825', 800: '#57411C', 900: '#3B2C13', 950: '#241B0B' };
const brick = { 50: '#FBF1EF', 100: '#F4DDD8', 200: '#E8BBB1', 300: '#DA978A', 400: '#CB7767', 500: '#B35D4D', 600: '#934B3E', 700: '#733B31', 800: '#552C25', 900: '#3A1F1A', 950: '#24130F' };
const stone = { 50: '#FAFAF9', 100: '#F5F5F4', 200: '#E7E5E4', 300: '#D6D3D1', 400: '#A8A29E', 500: '#7F7973', 600: '#57534E', 700: '#44403C', 800: '#292524', 900: '#1C1917', 950: '#0C0A09' };

export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        white: '#EDE9E3',
        background: '#121110',
        surface: {
          DEFAULT: '#161513',
          subtle: '#1E1D1A',
          card: '#1A1917',
          hover: '#22211E',
          border: '#2E2C28',
          borderLight: '#3A3732',
        },
        accent: {
          purple: ink[400],
          purpleLight: ink[300],
          purpleDark: ink[700],
          blue: ink[500],
          cyan: sand[400],
          cyanLight: sand[300],
          emerald: sage[400],
          amber: ochre[400],
          rose: brick[400],
        },
        // Old bright colours are remapped so the whole UI calms down at once
        purple: ink, violet: ink, indigo: ink, fuchsia: ink, pink: ink, blue: ink,
        cyan: sand, sky: sand, teal: sand,
        emerald: sage, green: sage,
        amber: ochre, yellow: ochre, orange: ochre,
        rose: brick, red: brick,
        slate: stone, gray: stone,
      },
      fontFamily: {
        sans: ['"IBM Plex Sans"', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
        serif: ['Fraunces', 'Georgia', 'serif'],
      },
      borderRadius: {
        xl: '0.5rem',
        '2xl': '0.625rem',
        '3xl': '0.75rem',
      },
      boxShadow: {
        glow: '0 1px 0 0 rgba(237, 233, 227, 0.04)',
        cyanGlow: '0 1px 0 0 rgba(237, 233, 227, 0.04)',
        card: '0 1px 2px 0 rgba(0, 0, 0, 0.35)',
      }
    },
  },
  plugins: [],
}
